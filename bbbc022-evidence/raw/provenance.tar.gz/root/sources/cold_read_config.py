"""Matched settings for the cold chunk and Blosc block experiment."""

CAPACITIES = (256,)
BLOCKS_BY_CHUNK = {32: (4, 16, 32), 128: (16, 64, 128), 512: (16, 64, 256, 512)}
CHUNK_KIB = tuple(BLOCKS_BY_CHUNK)
ADVICE = ("default", "random")
SETTINGS = {
    f"chunks256-{advice}": {
        "read_buffer_chunks": 256,
        "file_read_mode": f"persistent-{advice}",
        "readahead": advice,
    }
    for advice in ADVICE
}
VARIANTS = (*SETTINGS, "tensorstore")
WORKLOADS = ("random-1x256x256", "full-scan")
CODECS = ("lz4", "zstd")
ENCODINGS = tuple(
    (codec, chunk, block)
    for codec in CODECS
    for chunk, blocks in BLOCKS_BY_CHUNK.items()
    for block in blocks
)
LABELS = {
    "chunks256-default": "Damacy, default readahead",
    "chunks256-random": "Damacy, readahead disabled",
    "tensorstore": "TensorStore",
}
COLORS = dict(zip(VARIANTS, ("#2879ad", "#22884a", "#aa55b5"), strict=True))
COUNTERS = (
    "read_jobs",
    "opens",
    "closes",
    "random_advice_calls",
    "random_advice_errors",
    "batches_created",
    "batches_destroyed",
)
