"""Read identical batches through Damacy and TensorStore CPU backends."""

import dataclasses
import hashlib
import os
from collections import deque
from importlib.metadata import version

import cpu_pareto as base
from cold_read_config import COUNTERS, SETTINGS

BACKENDS = ("damacy", "tensorstore")


def check_values(values, first, hashes, shape):
    import numpy as np

    base.require(values.shape == shape, "unexpected output shape")
    base.require(values.dtype == np.float32, "expected float32 output")
    base.require(values.flags.c_contiguous, "expected contiguous output")
    checked = 0
    for local in range(len(values)):
        wanted = hashes.get(str(first + local))
        if wanted is not None:
            actual = hashlib.sha256(values[local].tobytes(order="C")).hexdigest()
            base.require(actual == wanted, "CPU crop differs from source")
            checked += 1
    return checked


class DamacyReader:
    def __init__(self, uri, workload, expected, chunk_bytes, workers, io_workers):
        import damacy

        self.damacy = damacy
        self.uri = uri
        self.batch_samples = workload["samples_per_batch"]
        self.sample_shape = tuple(workload["sample_shape"])
        damacy.set_log_level(damacy.LOG_WARN)
        self.reader = damacy.FileReader(workers=io_workers, max_inflight_reads=4096)
        file_mode = os.environ["DAMACY_BENCH_READ_MODE"]
        chunks = 256
        actual = self.file_stats()
        self.mode = f"chunks{chunks}-{actual['readahead']}"
        base.require(self.mode in SETTINGS, "unknown input-buffer variant")
        base.require(
            file_mode
            == SETTINGS[self.mode]["file_read_mode"]
            == actual["handles"] + "-" + actual["readahead"],
            "file-read mode was not applied",
        )
        self.executor = damacy.CpuExecutor(
            reader=self.reader,
            limits=damacy.CpuLimits(
                max_memory_bytes=2 * base.GIB,
                decode_workers=workers,
                max_encoded_chunk_bytes=chunk_bytes + 16,
                max_decoded_chunk_bytes=chunk_bytes,
            ),
        )
        cpu = self.cpu_settings()
        base.require(
            cpu
            == {
                "decode_workers": workers,
                "read_buffer_chunks": chunks,
                "encoded_bytes_per_buffer": chunks * (chunk_bytes + 16),
                "input_buffers": 2,
            },
            "native input-buffer or decode-worker setting differs",
        )
        self.pipeline = damacy.Pipeline(
            planner=damacy.ChunkPlanner(
                metadata=damacy.ZarrMetadata(
                    reader=damacy.FileMetadataReader(concurrency=8),
                    cache=damacy.MetadataCache(
                        array_entries=1024, shard_index_entries=8192
                    ),
                ),
                limits=damacy.PlanLimits(
                    max_chunks=max(16384, expected["max_chunk_uses_per_batch"]),
                    max_chunk_bytes=base.MIB,
                    max_shards_per_sample=4,
                    max_plan_bytes=64 * base.MIB,
                ),
            ),
            executor=self.executor,
            output=damacy.BatchSpec(self.batch_samples, self.sample_shape),
            queues=damacy.QueueLimits(
                lookahead_samples=4 * self.batch_samples, prepared_batches=2
            ),
            pop_timeout_s=None,
        )
        self.settings = {
            "implementation": self.mode,
            "file_read_mode": file_mode,
            **cpu,
            "file_handle_lifetime": actual["handles"],
            "readahead_advice": actual["readahead"],
            "decode_workers": workers,
            "decode_worker_scope": "decode and assembly; caller plus 31 pool threads at the 32-worker setting",
            "file_reader_workers": io_workers,
            "blosc_internal_threads": 1,
            "decoded_cache_bytes": 0,
            "prepared_batches": 2,
            "output_dtype": "float32",
            "reader_byte_counter_scope": "encoded chunk payloads; shard indexes are warmed before timing",
            "decoded_byte_counter_available": True,
        }

    def __enter__(self):
        self.pipeline.__enter__()
        base.require(self.pipeline.device == -1, "expected CPU output")
        return self

    def __exit__(self, *args):
        return self.pipeline.__exit__(*args)

    def prepare(self, starts, shape):
        import numpy as np

        base.require(tuple(shape) == self.sample_shape, "sample shape changed")
        samples = [
            self.damacy.Sample(
                self.uri, [(a, a + n) for a, n in zip(start, shape, strict=True)]
            )
            for start in starts
        ]
        base.require(len(samples) % self.batch_samples == 0, "partial batch")
        output_shape = (self.batch_samples, *shape)

        def read(hashes):
            self.pipeline.push(samples)
            checked = 0
            for first in range(0, len(samples), self.batch_samples):
                with self.pipeline.pop() as batch:
                    if hashes:
                        values = np.from_dlpack(batch)
                        checked += check_values(values, first, hashes, output_shape)
                        del values
            base.require(checked == len(hashes), "missing CPU output checks")
            return checked

        return read

    def file_stats(self):
        return self.damacy._native.bench_reader_stats(self.reader._native)

    def cpu_settings(self):
        return self.damacy._native.bench_cpu_settings(self.executor._native)

    def stats_reset(self):
        self.pipeline.stats_reset()
        self.file_before = self.file_stats()

    def stats(self):
        result = dataclasses.asdict(self.pipeline.stats())
        after = self.file_stats()
        result["file_reader"] = {
            key: after[key] - self.file_before[key] for key in COUNTERS
        }
        result["file_reader_total"] = after
        result["cpu_read_buffers"] = self.cpu_settings()
        return result


def tensorstore_context(workers, io_workers):
    return {
        "data_copy_concurrency": {"limit": workers},
        "file_io_concurrency": {"limit": io_workers},
        "file_io_mode": {"mode": "default"},
        "cache_pool": {"total_bytes_limit": 0},
        "cache_pool#metadata": {"total_bytes_limit": 64 * base.MIB},
    }


def tensorstore_crops(array, starts, shape):
    import tensorstore as ts

    return [
        array[tuple(slice(a, a + n) for a, n in zip(start, shape, strict=True))][
            ts.d[:].translate_to[0]
        ]
        for start in starts
    ]


def tensorstore_submit(layers, context):
    import tensorstore as ts

    with ts.Batch() as batch:
        future = ts.stack(layers, axis=0, context=context).read(order="C", batch=batch)
    return future


def tensorstore_file_metrics():
    import tensorstore as ts

    metrics = ts.experimental_collect_matching_metrics(
        "/tensorstore/kvstore/file/", include_zero_metrics=True
    )
    result = {}
    for metric in metrics:
        values = metric["values"]
        if len(values) == 1 and set(values[0]) == {"value"}:
            result[metric["name"]] = values[0]["value"]
    base.require(
        "/tensorstore/kvstore/file/bytes_read" in result,
        "TensorStore file byte counter is unavailable",
    )
    return result


class TensorStoreReader:
    def __init__(self, uri, workload, expected, chunk_bytes, workers, io_workers):
        import tensorstore as ts

        base.require(
            version("tensorstore") == "0.1.85", "unexpected TensorStore version"
        )
        self.batch_samples = workload["samples_per_batch"]
        self.sample_shape = tuple(workload["sample_shape"])
        context_spec = tensorstore_context(workers, io_workers)
        self.context = ts.Context(context_spec)
        self.shared_context = self.context
        self.shared_resources = {
            key: self.context[key]
            for key in (
                "data_copy_concurrency",
                "file_io_concurrency",
                "file_io_mode",
            )
        }
        self.source_spec = {
            "driver": "zarr3",
            "kvstore": {"driver": "file", "path": uri},
            "metadata_cache_pool": "cache_pool#metadata",
            "recheck_cached_metadata": False,
            "recheck_cached_data": False,
        }
        observed_context = {
            key: self.context[key].to_json(include_defaults=True)
            for key in context_spec
        }
        defaults = {
            "file_io_mode": {"mode": "default"},
            "cache_pool": {"total_bytes_limit": 0},
        }
        resolved_context = {
            resource: {**defaults.get(resource.split("#")[0], {}), **value}
            for resource, value in observed_context.items()
        }
        for resource, settings in context_spec.items():
            for key, wanted in settings.items():
                base.require(
                    resolved_context[resource].get(key) == wanted,
                    f"TensorStore {resource}.{key} changed: {observed_context[resource]}",
                )
        source = ts.open(
            self.source_spec, context=self.context, read=True, write=False
        ).result()
        self.array = source.astype(ts.float32)
        self.settings = {
            "version": version("tensorstore"),
            "context": resolved_context,
            "context_resource_json": observed_context,
            "resolved_spec": self.array.spec().to_json(),
            "decode_workers": workers,
            "decode_worker_scope": "data_copy_concurrency limits decode, conversion, copying and assembly",
            "file_reader_workers": io_workers,
            "blosc_internal_threads": 1,
            "decoded_cache_bytes": 0,
            "metadata_cache_bytes": 64 * base.MIB,
            "outstanding_batches": 2,
            "data_cache_resets": 0,
            "data_cache_reset_scope": "fresh data and metadata pools before every pass; worker resources shared; reset and index warming outside active time",
            "output_dtype": "float32",
            "batch_read": "native stack of translated crop views; explicit TensorStore batch",
            "reader_byte_counter_scope": "file-driver bytes, including shard indexes and merged read ranges",
            "decoded_byte_counter_available": False,
        }
        self.output_bytes = 0

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.array = None
        self.context = None
        self.shared_context = None
        self.shared_resources = None

    def reset_data_cache(self):
        import tensorstore as ts

        before = tensorstore_file_metrics()
        previous_pools = {
            key: self.context[key] for key in ("cache_pool", "cache_pool#metadata")
        }
        self.context = ts.Context(
            {
                "cache_pool": {"total_bytes_limit": 0},
                "cache_pool#metadata": {"total_bytes_limit": 64 * base.MIB},
            },
            parent=self.shared_context,
        )
        for key, previous in previous_pools.items():
            base.require(self.context[key] is not previous, f"cache pool reused: {key}")
        for key, resource in self.shared_resources.items():
            base.require(self.context[key] is resource, f"unshared resource: {key}")
        source = ts.open(
            self.source_spec, context=self.context, read=True, write=False
        ).result()
        indexes = [
            source[
                0, y * (source.shape[1] // 4), x * (source.shape[2] // 4)
            ].storage_statistics(query_fully_stored=True)
            for y in range(4)
            for x in range(4)
        ]
        base.require(
            all(future.result().fully_stored for future in indexes),
            "missing shard while warming indexes",
        )
        self.array = source.astype(ts.float32)
        after = tensorstore_file_metrics()
        for key in self.before:
            self.before[key] += after[key] - before[key]
        self.settings["data_cache_resets"] += 1

    def prepare(self, starts, shape):
        base.require(tuple(shape) == self.sample_shape, "sample shape changed")
        base.require(len(starts) % self.batch_samples == 0, "partial batch")
        layers = tensorstore_crops(self.array, starts, shape)
        batches = [
            (first, layers[first : first + self.batch_samples])
            for first in range(0, len(layers), self.batch_samples)
        ]
        output_shape = (self.batch_samples, *shape)

        def read(hashes):
            remaining = iter(batches)
            pending = deque()
            checked = 0

            def submit():
                item = next(remaining, None)
                if item is not None:
                    first, crops = item
                    pending.append((first, tensorstore_submit(crops, self.context)))

            submit()
            submit()
            while pending:
                first, future = pending.popleft()
                values = future.result()
                if hashes:
                    checked += check_values(values, first, hashes, output_shape)
                self.output_bytes += values.nbytes
                del values, future
                submit()
            base.require(checked == len(hashes), "missing TensorStore output checks")
            return checked

        return read

    def stats_reset(self):
        self.before = tensorstore_file_metrics()
        self.output_bytes = 0

    def stats(self):
        after = tensorstore_file_metrics()
        delta = {key: after[key] - value for key, value in self.before.items()}
        base.require(
            all(value >= 0 for value in delta.values()), "negative file counter"
        )
        return {"file_metrics": delta, "output_bytes": self.output_bytes}


def open_reader(backend, *args):
    return {"damacy": DamacyReader, "tensorstore": TensorStoreReader}[backend](*args)
