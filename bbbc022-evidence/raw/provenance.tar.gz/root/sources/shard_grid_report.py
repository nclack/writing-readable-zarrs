"""Compare CPU read bandwidth and amplification for matched backends."""

import argparse
import csv
import math
import statistics
from collections import defaultdict
from pathlib import Path

import cpu_pareto as base
from shard_grid_readers import BACKENDS

KEY_FIELDS = ("input", "codec", "chunk_kib", "block_kib", "workload", "cache")
RATE_FIELDS = (
    "storage_active_gib_s",
    "reader_active_gib_s",
    "decoded_active_gib_s",
    "useful_uint16_active_gib_s",
    "output_float32_active_gib_s",
    "storage_wall_gib_s",
    "output_float32_wall_gib_s",
    "storage_per_useful_byte",
    "reader_per_useful_byte",
    "decoded_per_useful_byte",
    "geometric_decoded_per_useful_byte",
    "cache_control_fraction",
)


def write_csv(path, rows):
    base.require(rows, "empty report")
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def pairing_signature(run):
    return {
        **{
            field: run[field]
            for field in (
                "audit_sha256",
                "references_sha256",
                "volume_shape",
                "shard_shape",
                "shard_grid",
                "sample_shape",
                "samples_per_batch",
                "query_count",
                "workers",
                "io_workers",
                "geometry",
                "storage",
                "stored_bytes",
                "raw_volume_bytes",
            )
        },
        "hostname": run["environment"]["hostname"],
        "affinity": run["environment"]["affinity"],
    }


def collect(results):
    complete = base.read_json(results / "complete.json")
    manifest = base.read_json(results / "manifest.json")
    groups = defaultdict(list)
    signatures = {}
    repetitions = []
    for relative in complete["results"]:
        run = base.read_json(results / relative)
        base.require(
            not run["diagnostic_only"], "traced reads cannot be throughput results"
        )
        base.require(
            run["workers"] == 32 and run["io_workers"] == 16, "thread budgets differ"
        )
        settings = run["backend_settings"]
        base.require(settings["decode_workers"] == 32, "unexpected decode limit")
        base.require(settings["file_reader_workers"] == 16, "unexpected reader limit")
        base.require(settings["blosc_internal_threads"] == 1, "nested Blosc threads")
        base.require(settings["output_dtype"] == "float32", "output dtype differs")
        record = {**run["case"], "workload": run["workload"], "cache": run["cache"]}
        key = tuple(record[field] for field in KEY_FIELDS)
        signature = pairing_signature(run)
        base.require(
            signatures.setdefault(key, signature) == signature,
            "unmatched files, queries, geometry, node, or affinity",
        )
        backend = run["backend"]
        base.require(backend in BACKENDS, "unknown backend")
        for row in run["measurements"]:
            groups[(*key, backend)].append(row)
            repetitions.append(
                {
                    **{field: record[field] for field in KEY_FIELDS},
                    "backend": backend,
                    "repeat": row["repeat"],
                    "passes": row["passes"],
                    "active_seconds": row["active_read_seconds"],
                    "wall_seconds": row["seconds"],
                    **{field: row[field] for field in RATE_FIELDS},
                    "source": relative,
                }
            )
    rows = []
    pairs = []
    for key in sorted(signatures):
        pair = dict(zip(KEY_FIELDS, key, strict=True))
        for backend in BACKENDS:
            values = groups[(*key, backend)]
            base.require(
                sorted(row["repeat"] for row in values)
                == list(range(1, manifest["repeats"] + 1)),
                "missing or duplicate backend repetition",
            )
            record = {**dict(zip(KEY_FIELDS, key, strict=True)), "backend": backend}
            record["stored_fraction"] = (
                signatures[key]["stored_bytes"] / signatures[key]["raw_volume_bytes"]
            )
            record["shards_per_batch"] = signatures[key]["geometry"][
                "min_shards_per_batch"
            ]
            record["queries_crossing_shards"] = signatures[key]["geometry"][
                "queries_crossing_shard_boundaries"
            ]
            for field in RATE_FIELDS:
                rates = [row[field] for row in values if row[field] is not None]
                for prefix, fn in (
                    ("", statistics.median),
                    ("min_", min),
                    ("max_", max),
                ):
                    record[prefix + field] = fn(rates) if rates else None
                pair[backend + "_" + field] = record[field]
            rows.append(record)
        damacy = {row["repeat"]: row for row in groups[(*key, "damacy")]}
        tensorstore = {row["repeat"]: row for row in groups[(*key, "tensorstore")]}
        ratios = [
            damacy[i]["output_float32_active_gib_s"]
            / tensorstore[i]["output_float32_active_gib_s"]
            for i in sorted(damacy)
        ]
        pair["damacy_over_tensorstore_output_rate"] = statistics.median(ratios)
        pair["min_damacy_over_tensorstore_output_rate"] = min(ratios)
        pair["max_damacy_over_tensorstore_output_rate"] = max(ratios)
        pairs.append(pair)
    return rows, pairs, repetitions


def frontier(rows, cost, rate):
    result = []
    best = -math.inf
    for row in sorted(rows, key=lambda r: (r[cost], -r[rate])):
        if row[rate] > best:
            result.append(row)
            best = row[rate]
    return result


def plots(rows, pairs, output, description):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D

    files = []
    colors = {"damacy": "#2166ac", "tensorstore": "#d6604d"}
    for cache in ("cold", "warm"):
        selected = [row for row in pairs if row["cache"] == cache]
        if not selected:
            continue
        figure, axes = plt.subplots(
            1, 2, figsize=(14, max(4, 0.32 * len(selected) + 1.8)), sharey=True
        )
        positions = list(range(len(selected)))
        labels = [
            f"{r['input']} {r['codec']} c{r['chunk_kib']}/b{r['block_kib']} {r['workload']}"
            for r in selected
        ]
        for axis, field, title in zip(
            axes,
            ("storage_active_gib_s", "output_float32_active_gib_s"),
            ("Actual local-storage bandwidth", "Returned float32 bandwidth"),
            strict=True,
        ):
            for offset, backend in zip((-0.18, 0.18), BACKENDS, strict=True):
                axis.barh(
                    [p + offset for p in positions],
                    [r[backend + "_" + field] for r in selected],
                    height=0.32,
                    color=colors[backend],
                    label=backend,
                )
            axis.set_xlabel("GiB/s over active pipeline time")
            axis.set_title(title)
            axis.grid(axis="x", alpha=0.2)
            axis.set_axisbelow(True)
        axes[0].set_yticks(positions, labels, fontsize=8)
        axes[0].invert_yaxis()
        axes[1].legend()
        figure.suptitle(
            f"{cache.capitalize()} reads · {description}\n32 decode/copy workers and 16 readers per backend"
        )
        figure.tight_layout()
        name = f"{cache}-bandwidth.png"
        figure.savefig(output / name, dpi=160)
        figure.savefig(output / name.replace(".png", ".svg"))
        plt.close(figure)
        files.append(name)

    codec_colors = {"lz4": "#00876c", "zstd": "#8e44ad"}
    markers = {16: "o", 64: "s", 256: "^", 1024: "D"}
    for cache, cost, label in (
        (
            "cold",
            "storage_per_useful_byte",
            "Actual storage bytes / useful uint16 byte",
        ),
        ("warm", "stored_fraction", "Encoded volume bytes / raw uint16 volume byte"),
    ):
        selected = [
            r
            for r in rows
            if r["workload"] == "random-1x256x256" and r["cache"] == cache
        ]
        inputs = sorted({r["input"] for r in selected})
        if not inputs:
            continue
        figure, axes = plt.subplots(
            len(inputs),
            2,
            squeeze=False,
            sharex="row",
            sharey="row",
            figsize=(12, 4.5 * len(inputs)),
        )
        for i, fill in enumerate(inputs):
            for j, backend in enumerate(BACKENDS):
                axis = axes[i, j]
                values = [
                    r
                    for r in selected
                    if r["input"] == fill and r["backend"] == backend
                ]
                for r in values:
                    y = r["output_float32_active_gib_s"]
                    axis.errorbar(
                        r[cost],
                        y,
                        yerr=[
                            [y - r["min_output_float32_active_gib_s"]],
                            [r["max_output_float32_active_gib_s"] - y],
                        ],
                        color=codec_colors[r["codec"]],
                        linewidth=0.7,
                        alpha=0.7,
                        capsize=2,
                    )
                    axis.scatter(
                        r[cost],
                        y,
                        s=30 + 8 * math.log2(r["block_kib"]),
                        marker=markers[r["chunk_kib"]],
                        color=codec_colors[r["codec"]],
                    )
                    if len(values) <= 16:
                        axis.annotate(
                            f"c{r['chunk_kib']}/b{r['block_kib']}",
                            (r[cost], y),
                            xytext=(4, 5),
                            textcoords="offset points",
                            fontsize=7,
                        )
                edge = frontier(values, cost, "output_float32_active_gib_s")
                axis.plot(
                    [r[cost] for r in edge],
                    [r["output_float32_active_gib_s"] for r in edge],
                    color="#555555",
                    linestyle="--",
                    linewidth=0.8,
                )
                axis.set_title(f"{fill} · {backend}")
                axis.set_xlabel(label)
                axis.set_ylabel("Returned float32 GiB/s")
                axis.grid(alpha=0.2)
            maximum = max(
                row["max_output_float32_active_gib_s"]
                for row in selected
                if row["input"] == fill
            )
            axes[i, 0].set_ylim(0, 1.12 * maximum)
            axes[i, 0].margins(x=0.12)
        handles = [
            Line2D([], [], color=color, marker="o", linestyle="none", label=codec)
            for codec, color in codec_colors.items()
        ]
        handles += [
            Line2D(
                [],
                [],
                color="#555555",
                marker=marker,
                linestyle="none",
                label=f"{chunk} KiB chunk",
            )
            for chunk, marker in markers.items()
            if chunk in {row["chunk_kib"] for row in selected}
        ]
        figure.legend(handles=handles, loc="lower center", ncol=6, fontsize=8)
        figure.suptitle(
            f"{cache.capitalize()} translated 256x256 crops · {description}\n32 decode/copy workers and 16 readers per backend"
        )
        figure.tight_layout(rect=(0, 0.05, 1, 0.96))
        name = "storage-pareto.png" if cache == "cold" else "warm-pareto.png"
        figure.savefig(output / name, dpi=160)
        figure.savefig(output / name.replace(".png", ".svg"))
        plt.close(figure)
        files.append(name)
    return files


def report(results, output):
    rows, pairs, repetitions = collect(results)
    manifest = base.read_json(results / "manifest.json")
    complete = base.read_json(results / "complete.json")
    first = base.read_json(results / complete["results"][0])
    profile = manifest["profile"]
    description = (
        f"{profile} · {first['raw_volume_bytes'] / base.GIB:g} GiB uint16 / 16 shards"
    )
    output.mkdir(parents=True, exist_ok=False)
    write_csv(output / "summary.csv", rows)
    write_csv(output / "comparison.csv", pairs)
    write_csv(output / "repetitions.csv", repetitions)
    traces = []
    for path in sorted(results.glob("*/concurrency/*/concurrency.json")):
        traces.append(
            {
                "setting": path.parents[2].name,
                "backend": path.parent.name,
                **base.read_json(path),
            }
        )
    base.write_json(output / "concurrency.json", traces)
    plot_files = plots(rows, pairs, output, description)
    lines = [
        f"# Damacy and TensorStore CPU read comparison: {profile}",
        "",
        f"Volume z/y/x: {first['volume_shape']} uint16, {first['raw_volume_bytes'] / base.GIB:g} GiB uncompressed. Shard grid: {first['shard_grid']}, each shard {first['shard_shape']} and {math.prod(first['shard_shape']) * 2 / base.GIB:g} GiB uncompressed. Compressed file sizes depend on codec and input. Translated and aligned queries are 1x256x256; the full-scan control uses 8x256x256 tiles. Both codecs use level 3 and bitshuffle.",
        "",
        f"This is the **{profile}** profile, with {manifest['repeats']} repetition(s) per backend and at least {manifest['seconds']} active seconds per repetition. The preflight is a small correctness check; the pilot covers only 64 KiB chunks / 16 KiB blocks and cannot determine the optimum across chunk and block sizes.",
        "",
        "Both backends read the same uint16 volume, encoded files, and query sequence, using 32 decode/copy participants and 16 file readers on the same physical CPU allocation. Each paired repetition uses separate processes, with the first backend alternating between repetitions. Outputs are contiguous float32 batches. TensorStore receives fresh data and metadata cache pools before every pass, sharing the same 32/16 worker resources. Metadata and shard indexes are warmed without decoding data before timing. Damacy has no decoded-data cache.",
        "",
        "Rates divide bytes by active pipeline time, including read, decompression, conversion and assembly. Storage bytes are process-attributed block-backed reads in those same intervals. Float32 output bytes are twice useful uint16 bytes. Cache resets, metadata warming, crop preparation, eviction, residency checks and validation are outside active time; repetition wall rates and cache-control overhead remain in the CSV. Repetition wall time includes per-pass preparation and cache controls, but excludes process startup, initial warmup and correctness validation. Warm reads do not measure the storage ceiling.",
        "",
        "Cold passes begin with zero resident pages in the shard files. Readahead and reuse within a pass are allowed. The corpus fits RAM, so these are repeated cold passes rather than a continuous larger-than-cache stream.",
        "",
        "| Setting (input / codec / chunk / block) | Workload | Cache | Damacy storage GiB/s | TensorStore storage GiB/s | Damacy float32 GiB/s | TensorStore float32 GiB/s | Damacy / TensorStore output rate |",
        "|---|---|---|---:|---:|---:|---:|---:|",
    ]
    for row in pairs:
        name = f"{row['input']} / {row['codec']} / {row['chunk_kib']} / {row['block_kib']} KiB"
        lines.append(
            f"| {name} | {row['workload']} | {row['cache']} | {row['damacy_storage_active_gib_s']:.3f} | {row['tensorstore_storage_active_gib_s']:.3f} | {row['damacy_output_float32_active_gib_s']:.3f} | {row['tensorstore_output_float32_active_gib_s']:.3f} | {row['damacy_over_tensorstore_output_rate']:.3f}x |"
        )
    lines += [
        "",
        "Rates are medians. The ratio is the median of paired repetition ratios; values above one favor Damacy. CSV files retain every repetition and observed ranges, which are not confidence intervals.",
        "",
        "| Setting | Workload | Damacy storage / useful byte | TensorStore storage / useful byte | Chunk bytes / useful byte (geometry model) |",
        "|---|---|---:|---:|---:|",
    ]
    for row in pairs:
        if row["cache"] != "cold":
            continue
        name = f"{row['input']} {row['codec']} c{row['chunk_kib']}/b{row['block_kib']}"
        lines.append(
            f"| {name} | {row['workload']} | {row['damacy_storage_per_useful_byte']:.3f} | {row['tensorstore_storage_per_useful_byte']:.3f} | {row['damacy_geometric_decoded_per_useful_byte']:.3f} |"
        )
    lines += [
        "",
        "The geometric model counts each intersected chunk once per batch. Damacy's native counters validate that decoded-byte count. TensorStore does not expose an equivalent decoded-byte counter; its measured value is left blank. In-progress reuse and request merging may differ between implementations. TensorStore reader-byte counters include shard indexes and merged ranges; Damacy's reader counter counts chunk payloads. Neither is substituted for actual storage traffic.",
        "",
        "Every batch includes all sixteen shards. The separate pread trace measures actual distinct-file overlap and is excluded from throughput timings.",
    ]
    if traces:
        lines += [
            "",
            "| Setting | Backend | Peak overlapping shards | Mean overlapping shards | Time at 16 |",
            "|---|---|---:|---:|---:|",
        ]
        for row in traces:
            lines.append(
                f"| {row['setting']} | {row['backend']} | {row['peak_concurrent_shards']} | {row['mean_concurrent_shards']:.2f} | {row['fraction_at_sixteen_shards']:.1%} |"
            )
        if any(row["peak_concurrent_shards"] < 16 for row in traces):
            lines += [
                "",
                "**At least one diagnostic did not reach sixteen overlapping shards. Do not claim sixteen-way read concurrency for every backend and setting.**",
            ]
    lines += [
        "",
        "Plots use identical axes for both backends. Cold Pareto curves compare actual storage amplification against output bandwidth. Warm curves compare the encoded volume size against output bandwidth. Both favor lower byte cost and higher output bandwidth; dashed lines join the observed frontier. Chunk/block labels are KiB; larger symbols indicate larger blocks. Vertical bars show observed output-rate ranges.",
        "",
    ]
    lines += [f"![{name.removesuffix('.png')}]({name})\n" for name in plot_files]
    lines += [
        "[Backend summaries](summary.csv) · [paired comparison](comparison.csv) · [individual repetitions](repetitions.csv) · [read-overlap diagnostics](concurrency.json).",
        "",
    ]
    (output / "README.md").write_text("\n".join(lines))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report(args.results, args.output)


if __name__ == "__main__":
    main()
