"""Build one volume partitioned into a grid of sharded files."""

import argparse
import hashlib
import itertools
import math
import random
import struct
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import cpu_pareto as base

GRID = (1, 4, 4)
SHARD_SHAPE = (512, 1024, 1024)
SMALL_SHARD_SHAPE = (8, 512, 512)
CROP_SHAPE = (1, 256, 256)
SPACINGS = ((16, 128, 128), (4, 32, 32))
WEIGHTS = (0.35, 0.65)


def coordinates(grid=GRID):
    return list(itertools.product(*(range(size) for size in grid)))


def volume_shape(shard_shape):
    return tuple(a * b for a, b in zip(shard_shape, GRID, strict=True))


def shard_selection(coordinate, shard_shape):
    return tuple(
        slice(index * size, (index + 1) * size)
        for index, size in zip(coordinate, shard_shape, strict=True)
    )


def source_name(coordinate):
    return "-".join(map(str, coordinate)) + ".npy"


def smooth_source(shard_shape, coordinate, seed):
    import numpy as np

    shape = volume_shape(shard_shape)
    origin = tuple(a * b for a, b in zip(coordinate, shard_shape, strict=True))
    rng = np.random.default_rng(seed + 50000)
    fields = []
    for spacing, weight in zip(SPACINGS, WEIGHTS, strict=True):
        size = tuple(
            (n - 1) // step + 2 for n, step in zip(shape, spacing, strict=True)
        )
        grid = rng.integers(0, 4096, size, dtype=np.uint16).astype(np.float32)
        grid *= np.float32(weight)
        positions = [
            np.arange(begin, begin + size, dtype=np.float32) / step
            for begin, size, step in zip(origin, shard_shape, spacing, strict=True)
        ]
        lower = [p.astype(np.intp) for p in positions]
        weights = []
        for p, index in zip(positions, lower, strict=True):
            f = p - index
            weights.append(np.asarray(f * f * (3 - 2 * f), dtype=np.float32))
        z, y, x = lower
        wz, wy, wx = weights
        along_x = grid[:, :, x] * (1 - wx) + grid[:, :, x + 1] * wx
        planes = (
            along_x[:, y, :] * (1 - wy)[None, :, None]
            + along_x[:, y + 1, :] * wy[None, :, None]
        )
        fields.append((planes, z, wz))
    shard_index = coordinates().index(tuple(coordinate))
    noise_rng = np.random.default_rng(seed + 60000 + shard_index)
    result = np.empty(shard_shape, dtype=np.uint16)
    for plane in range(shard_shape[0]):
        values = np.zeros(shard_shape[1:], dtype=np.float32)
        for planes, z, wz in fields:
            f = wz[plane]
            values += planes[z[plane]] * (1 - f) + planes[z[plane] + 1] * f
        np.clip(values, 0, 4095, out=values)
        signal = np.rint(values).astype(np.uint16)
        noise = noise_rng.integers(0, 256, shard_shape[1:], dtype=np.uint16)
        result[plane] = (signal & np.uint16(4080)) | (noise & np.uint16(15))
    return result


def prepare_sources(cache, fill, shard_shape):
    import numpy as np

    folder = cache / fill
    description = {
        "input": fill,
        "seed": base.SEED,
        "grid": list(GRID),
        "shard_shape": list(shard_shape),
        "generator_sha256": base.digest(Path(__file__)),
    }
    saved = folder / "sources.json"
    if saved.exists():
        result = base.read_json(saved)
        base.require(result["description"] == description, "source cache changed")
        base.require(
            all((folder / row["path"]).is_file() for row in result["shards"]),
            "source cache incomplete",
        )
        return result
    folder.mkdir(parents=True, exist_ok=False)

    def make_source(item):
        index, coordinate = item
        if fill == "smooth4":
            source = smooth_source(shard_shape, coordinate, base.SEED)
        elif fill == "random12":
            source = base.array_data(fill, shard_shape, base.SEED + index)
        else:
            raise ValueError(f"unsupported input: {fill}")
        path = folder / source_name(coordinate)
        digest = hashlib.sha256(memoryview(source)).hexdigest()
        np.save(path, source, allow_pickle=False)
        return {"coordinate": coordinate, "path": path.name, "sha256": digest}

    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(make_source, enumerate(coordinates())))
    result = {"description": description, "shards": rows}
    base.write_json(saved, result)
    return result


def intersected_shards(start, sample_shape, shard_shape):
    return list(
        itertools.product(
            *(
                range(begin // size, (begin + count - 1) // size + 1)
                for begin, count, size in zip(
                    start, sample_shape, shard_shape, strict=True
                )
            )
        )
    )


def expected_crop(cache, fill, start, sample_shape, shard_shape):
    import numpy as np

    result = np.empty(sample_shape, dtype=np.float32)
    for coordinate in intersected_shards(start, sample_shape, shard_shape):
        origin = tuple(a * b for a, b in zip(coordinate, shard_shape, strict=True))
        lo = tuple(max(a, b) for a, b in zip(start, origin, strict=True))
        hi = tuple(
            min(a + n, b + size)
            for a, n, b, size in zip(
                start, sample_shape, origin, shard_shape, strict=True
            )
        )
        source = np.load(
            cache / fill / source_name(coordinate), mmap_mode="r", allow_pickle=False
        )
        source_slices = tuple(
            slice(a - b, c - b) for a, b, c in zip(lo, origin, hi, strict=True)
        )
        target_slices = tuple(
            slice(a - b, c - b) for a, b, c in zip(lo, start, hi, strict=True)
        )
        result[target_slices] = source[source_slices]
        del source
    return result


def query_workloads(shard_shape, count):
    shape = volume_shape(shard_shape)
    rng = random.Random(base.SEED + 2000)
    base.require(count % 128 == 0, "query count must fill batches")
    translated = []
    tiles = coordinates()
    for sample in range(count):
        coordinate = tiles[sample % len(tiles)]
        start = [rng.randrange(shape[0])]
        for tile, size, extent, crop in zip(
            coordinate[1:], shard_shape[1:], shape[1:], CROP_SHAPE[1:], strict=True
        ):
            lo = tile * size
            hi = min((tile + 1) * size - 1, extent - crop)
            start.append(rng.randint(lo, hi))
        translated.append(start)
    aligned = [[z, y // 256 * 256, x // 256 * 256] for z, y, x in translated]
    full = [
        [
            offset + tile * size
            for offset, tile, size in zip(local, coordinate, shard_shape, strict=True)
        ]
        for local in base.grid(shard_shape)
        for coordinate in tiles
    ]
    return [
        {"name": "random-1x256x256", "queries": translated, "sample_shape": CROP_SHAPE},
        {"name": "aligned", "queries": aligned, "sample_shape": CROP_SHAPE},
        {"name": "full-scan", "queries": full, "sample_shape": base.SAMPLE_SHAPE},
    ]


def boundary_queries(shard_shape):
    shape = volume_shape(shard_shape)
    positions = []
    for d in (1, 2):
        positions.append(
            sorted(
                {0, shape[d] - 256, *(i * shard_shape[d] - 128 for i in range(1, 4))}
            )
        )
    items = [[z, y, x] for z, y, x in itertools.product((0, shape[0] - 1), *positions)]
    return [items[i % len(items)] for i in range(128)]


def generate(case_path, data, cache, output, small):
    import numpy as np
    import tensorstore as ts

    case = base.read_json(case_path)
    shard_shape = SMALL_SHARD_SHAPE if small else SHARD_SHAPE
    shape = volume_shape(shard_shape)
    source_info = prepare_sources(cache, case["input"], shard_shape)
    data.mkdir(parents=True, exist_ok=False)
    array = data / "volume"
    context = ts.Context(
        {
            "data_copy_concurrency": {"limit": 32},
            "file_io_concurrency": {"limit": 16},
            "cache_pool": {"total_bytes_limit": 0},
        }
    )
    store = ts.open(
        base.tensorstore_spec(array, case, shape, shard_shape),
        create=True,
        context=context,
    ).result()
    started = time.perf_counter()
    audits = []
    for row in source_info["shards"]:
        coordinate = tuple(row["coordinate"])
        source = np.load(
            cache / case["input"] / row["path"], mmap_mode="r", allow_pickle=False
        )
        base.require(
            hashlib.sha256(memoryview(source)).hexdigest() == row["sha256"],
            "cached source changed",
        )
        writer = base.write_shard(array, source, case, coordinate)
        decoded = store[shard_selection(coordinate, shard_shape)].read().result()
        base.require(
            np.array_equal(source, decoded), "TensorStore full-shard readback differs"
        )
        del decoded
        audit = base.audit_array(array, case, shard_shape, coordinate)
        audit.update(
            {"coordinate": coordinate, "source_sha256": row["sha256"], "writer": writer}
        )
        audits.append(audit)
        del source
    count = 128 if small else 16384
    workloads = query_workloads(shard_shape, count)
    for workload in workloads:
        queries = workload["queries"]
        selected = (
            set(range(len(queries)))
            if small
            else {index * (len(queries) - 1) // 127 for index in range(128)}
        )
        workload["float32_sha256"] = {}
        for index in sorted(selected):
            values = expected_crop(
                cache,
                case["input"],
                queries[index],
                workload["sample_shape"],
                shard_shape,
            )
            workload["float32_sha256"][str(index)] = hashlib.sha256(
                values.tobytes(order="C")
            ).hexdigest()
        workload["samples_per_batch"] = min(128, len(queries))
        workload["logical_bytes_per_pass"] = (
            len(queries) * math.prod(workload["sample_shape"]) * 2
        )
    validation = boundary_queries(shard_shape)
    checks = {}
    for index, start in enumerate(validation):
        expected = expected_crop(cache, case["input"], start, CROP_SHAPE, shard_shape)
        selection = tuple(
            slice(a, a + n) for a, n in zip(start, CROP_SHAPE, strict=True)
        )
        actual = store[selection].read().result().astype(np.float32)
        base.require(
            np.array_equal(expected, actual), "TensorStore cross-shard crop differs"
        )
        checks[str(index)] = hashlib.sha256(expected.tobytes(order="C")).hexdigest()
    base.write_json(
        output / "references.json",
        {
            "source_sha256": [row["source_sha256"] for row in audits],
            "workloads": workloads,
            "validation": {
                "queries": validation,
                "float32_sha256": checks,
                "sample_shape": CROP_SHAPE,
            },
        },
    )
    total_bytes = sum(row["file_bytes"] for row in audits)
    raw_bytes = math.prod(shape) * 2
    base.write_json(
        output / "audit.json",
        {
            "case": case,
            "array_path": "volume",
            "shape": shape,
            "shard_shape": shard_shape,
            "shard_grid": GRID,
            "shards": audits,
            "logical_bytes": raw_bytes,
            "stored_bytes": total_bytes,
            "compression_ratio": raw_bytes / total_bytes,
            "generation_seconds": time.perf_counter() - started,
            "tensorstore_full_readback": True,
            "tensorstore_boundary_crops_checked": len(validation),
        },
    )


def chunks_for_query(start, sample_shape, chunk):
    return itertools.product(
        *(
            range(begin // size, (begin + count - 1) // size + 1)
            for begin, count, size in zip(start, sample_shape, chunk, strict=True)
        )
    )


def chunk_location(coordinate, chunks_per_shard):
    shard = tuple(a // b for a, b in zip(coordinate, chunks_per_shard, strict=True))
    local = tuple(a % b for a, b in zip(coordinate, chunks_per_shard, strict=True))
    index = (local[0] * chunks_per_shard[1] + local[1]) * chunks_per_shard[2] + local[2]
    return shard, index


def geometry(data, audit, workload, page_bytes, include_ranges=False):
    chunk = base.CHUNKS[audit["case"]["chunk_kib"]]
    chunk_bytes = math.prod(chunk) * 2
    shard_shape = audit["shard_shape"]
    inner = tuple(a // b for a, b in zip(shard_shape, chunk, strict=True))
    indexes = {}
    pages = {}
    for row in audit["shards"]:
        coordinate = tuple(row["coordinate"])
        with (data / row["path"]).open("rb") as stream:
            stream.seek(-row["index_bytes"], 2)
            indexes[coordinate] = list(
                struct.iter_unpack("<QQ", stream.read(row["index_bytes"] - 4))
            )
        pages[coordinate] = bytearray(
            (row["file_bytes"] + page_bytes - 1) // page_bytes
        )
    total_chunks = encoded = uses = max_unique = max_uses = 0
    all_chunks = set()
    shards_per_batch = []
    batch = workload["samples_per_batch"]
    for first in range(0, len(workload["queries"]), batch):
        touched = set()
        batch_uses = 0
        for start in workload["queries"][first : first + batch]:
            current = list(chunks_for_query(start, workload["sample_shape"], chunk))
            batch_uses += len(current)
            touched.update(current)
        total_chunks += len(touched)
        max_unique = max(max_unique, len(touched))
        max_uses = max(max_uses, batch_uses)
        uses += batch_uses
        batch_shards = set()
        for coordinate in touched:
            shard, index = chunk_location(coordinate, inner)
            encoded += indexes[shard][index][1]
            batch_shards.add(shard)
        shards_per_batch.append(len(batch_shards))
        all_chunks.update(touched)
    required_ranges = []
    for coordinate in all_chunks:
        shard, index = chunk_location(coordinate, inner)
        offset, size = indexes[shard][index]
        if include_ranges:
            required_ranges.append([shard[1] * GRID[2] + shard[2], offset, size])
        first = offset // page_bytes
        end = (offset + size + page_bytes - 1) // page_bytes
        pages[shard][first:end] = b"\1" * (end - first)
    covered = sum(sum(vector) for vector in pages.values()) * page_bytes
    useful = workload["logical_bytes_per_pass"]
    result = {
        "unique_chunks_per_pass": total_chunks,
        "chunk_uses_per_pass": uses,
        "encoded_bytes_per_pass": encoded,
        "decoded_bytes_per_pass": total_chunks * chunk_bytes,
        "decoded_per_useful_byte": total_chunks * chunk_bytes / useful,
        "max_unique_chunks_per_batch": max_unique,
        "max_chunk_uses_per_batch": max_uses,
        "min_shards_per_batch": min(shards_per_batch),
        "max_shards_per_batch": max(shards_per_batch),
        "minimum_storage_bytes_per_pass": max(512, covered - len(pages) * page_bytes),
        "queries_crossing_shard_boundaries": sum(
            len(intersected_shards(start, workload["sample_shape"], shard_shape)) > 1
            for start in workload["queries"]
        ),
    }

    if include_ranges:
        result["required_chunk_ranges"] = sorted(required_ranges)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("case", "data", "cache", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--small", action="store_true")
    args = parser.parse_args()
    generate(args.case, args.data, args.cache, args.output, args.small)


if __name__ == "__main__":
    main()
