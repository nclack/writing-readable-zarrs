"""Validate client cache state and count local or NFS reads."""

import os
import re
import resource
import time
from pathlib import Path

import cpu_pareto as base
import cpu_storage_reads as local

PAGE = local.PAGE
BYTE_FIELDS = (
    "application_read_bytes",
    "application_write_bytes",
    "direct_read_bytes",
    "direct_write_bytes",
    "payload_read_bytes",
    "payload_write_bytes",
    "read_pages",
    "write_pages",
)
RPC_FIELDS = (
    "operations",
    "transmissions",
    "major_timeouts",
    "sent_bytes",
    "received_bytes",
    "queue_milliseconds",
    "rtt_milliseconds",
    "execute_milliseconds",
    "errors",
)


def unescape(value):
    return re.sub(r"\\([0-7]{3})", lambda m: chr(int(m[1], 8)), value)


def mount_for(path):
    path = Path(path).resolve()
    matches = []
    for line in Path("/proc/self/mountinfo").read_text().splitlines():
        left, right = line.split(" - ", 1)
        fields, tail = left.split(), right.split()
        target = Path(unescape(fields[4]))
        if path.is_relative_to(target):
            matches.append(
                {
                    "target": str(target),
                    "source": unescape(tail[1]),
                    "filesystem": tail[0],
                    "options": tail[2],
                }
            )
    base.require(matches, f"no mount found for {path}")
    return max(matches, key=lambda row: len(row["target"]))


def parse_mountstats(contents, target):
    selected = []
    active = False
    for line in contents.splitlines():
        if line.startswith("device "):
            match = re.fullmatch(
                r"device (\S+) mounted on (\S+) with fstype (\S+)(?: statvers=(\S+))?",
                line,
            )
            active = bool(match and unescape(match[2]) == target)
            if active:
                base.require(match[3] in ("nfs", "nfs4"), "not an NFS mount")
                base.require(not selected, "duplicate NFS mount statistics")
                selected.append(line)
        elif active:
            selected.append(line)
    base.require(selected, f"NFS counters unavailable for {target}")
    counters = {}
    for line in selected:
        key, separator, value = line.strip().partition(":")
        if not separator:
            continue
        if key == "bytes":
            values = list(map(int, value.split()))
            base.require(len(values) == len(BYTE_FIELDS), "unknown NFS byte fields")
            counters.update(zip(BYTE_FIELDS, values, strict=True))
        elif key in ("READ", "GETATTR", "ACCESS", "LOOKUP"):
            values = list(map(int, value.split()))
            base.require(len(values) in (8, 9), "unknown RPC counter fields")
            counters.update(
                {
                    f"{key}.{field}": count
                    for field, count in zip(
                        RPC_FIELDS[: len(values)], values, strict=True
                    )
                }
            )
    base.require("payload_read_bytes" in counters, "NFS payload bytes unavailable")
    base.require("READ.operations" in counters, "NFS READ counters unavailable")
    return counters


def difference(before, after):
    base.require(before.keys() == after.keys(), "counter fields changed")
    result = {key: after[key] - value for key, value in before.items()}
    base.require(all(value >= 0 for value in result.values()), "counter reset detected")
    return result


def total(rows):
    if not rows:
        return {}
    return {key: sum(row[key] for row in rows) for key in rows[0]}


def interval(before, after):
    return {
        "seconds": after["counter_time"] - before["counter_time"],
        "process_io": difference(before["process_io"], after["process_io"]),
        "nfs": difference(before["nfs"], after["nfs"]),
        "devices": {
            key: difference(before["devices"][key], after["devices"][key])
            for key in before["devices"]
        },
        "cpu": difference(before["cpu"], after["cpu"]),
    }


def block_devices(device):
    found = {}
    pending = [device]
    while pending:
        path = pending.pop().resolve()
        if path.name in found:
            continue
        found[path.name] = path
        pending.extend((path / "slaves").iterdir())
    return list(found.values())


class Files(local.Files):
    def __init__(self, paths):
        self.mount = mount_for(paths[0])
        self.nfs_mount = os.environ.get("DAMACY_NFS_MOUNT", "/mnt/main0")
        self.tier = "nfs" if self.mount["filesystem"] in ("nfs", "nfs4") else "local"
        expected = os.environ.get("DAMACY_STORAGE_TIER")
        base.require(expected is None or expected == self.tier, "wrong storage tier")
        if self.tier == "local":
            super().__init__(paths)
            self.devices = block_devices(self.device)
        else:
            self.paths = [Path(path) for path in paths]
            self.fds = []
            self.device = None
            self.devices = []
            base.require(
                len({path.stat().st_dev for path in self.paths}) == 1,
                "shards cross filesystems",
            )
            base.require(self.mount["target"] == self.nfs_mount, "wrong NFS mount")
            base.require(
                "fsc" not in self.mount["options"].split(","), "NFS disk cache enabled"
            )
        self.snapshot()

    def device_io(self):
        result = {}
        for device in self.devices:
            values = list(map(int, (device / "stat").read_text().split()))
            result[device.name] = {
                "read_operations": values[0],
                "merged_reads": values[1],
                "read_bytes": values[2] * 512,
                "read_milliseconds": values[3],
                "write_operations": values[4],
                "write_bytes": values[6] * 512,
                "io_milliseconds": values[9],
                "weighted_io_milliseconds": values[10],
            }
        return result

    def snapshot(self):
        start = time.perf_counter()
        nfs = parse_mountstats(
            Path("/proc/self/mountstats").read_text(), self.nfs_mount
        )
        sampled = time.perf_counter()
        usage = resource.getrusage(resource.RUSAGE_SELF)
        return {
            "counter_time": (start + sampled) / 2,
            "nfs_sample_seconds": sampled - start,
            "nfs": nfs,
            "devices": self.device_io(),
            "process_io": local.process_io(),
            "cpu": {"user_seconds": usage.ru_utime, "system_seconds": usage.ru_stime},
        }

    def idle(self):
        before = self.snapshot()
        time.sleep(0.25)
        after = self.snapshot()
        return interval(before, after)

    def description(self):
        return {
            "tier": self.tier,
            "mount": self.mount,
            "page_bytes": PAGE,
            "filesystem_device": self.device.resolve().name if self.device else None,
            "device_counters": [device.name for device in self.devices],
            "nfs_counter_mount": self.nfs_mount,
            "nfs_counter_scope": "shared client mount counters; may include other processes; not server disk bytes",
            "nfs_server_cache": "uncontrolled; generation and validation may warm it",
            "files": [
                {
                    "path": str(path),
                    "file_bytes": path.stat().st_size,
                    "allocated_bytes": path.stat().st_blocks * 512,
                }
                for path in self.paths
            ],
        }

    def measure(
        self,
        scan,
        *,
        cold,
        seconds,
        min_useful_bytes,
        useful_bytes_per_pass,
        minimum_storage_bytes,
        prepare=None,
    ):
        base.require(cold, "this experiment only measures cold client reads")
        idle_before = self.idle()
        passes = []
        control_seconds = active_seconds = 0.0
        wall_before = self.snapshot()
        started = time.perf_counter()
        while True:
            control_started = time.perf_counter()
            if prepare:
                prepare()
            residency = self.evict()
            control_seconds += time.perf_counter() - control_started
            before = self.snapshot()
            pass_started = time.perf_counter()
            scan()
            elapsed = time.perf_counter() - pass_started
            after = self.snapshot()
            delta = interval(before, after)
            byte_count = (
                delta["process_io"]["read_bytes"]
                if self.tier == "local"
                else delta["nfs"]["payload_read_bytes"]
            )
            base.require(
                byte_count >= minimum_storage_bytes,
                f"insufficient {self.tier} reads: {byte_count} < {minimum_storage_bytes}",
            )
            active_seconds += elapsed
            passes.append(
                {
                    "active_seconds": elapsed,
                    "counter_window_seconds": delta["seconds"],
                    "resident_pages_before": residency,
                    "eviction_attempts": self.last_eviction_attempts,
                    "eviction_stable_seconds": 0.02,
                    "process_io": delta["process_io"],
                    "nfs_io": delta["nfs"],
                    "device_io": delta["devices"],
                    "cpu": delta["cpu"],
                    "counters_before": before,
                    "counters_after": after,
                    "minimum_read_bytes_check": byte_count,
                }
            )
            if (
                active_seconds >= seconds
                and len(passes) * useful_bytes_per_pass >= min_useful_bytes
            ):
                break
        wall_seconds = time.perf_counter() - started
        wall_after = self.snapshot()
        wall_delta = interval(wall_before, wall_after)
        idle_after = self.idle()
        nfs = total([row["nfs_io"] for row in passes])
        counters_seconds = sum(row["counter_window_seconds"] for row in passes)
        nfs_ops = nfs["READ.operations"]
        storage_bytes = (
            wall_delta["process_io"]["read_bytes"] if self.tier == "local" else None
        )
        idle_payload_rate = max(
            row["nfs"]["payload_read_bytes"] / row["seconds"]
            for row in (idle_before, idle_after)
        )
        active_payload_rate = nfs["payload_read_bytes"] / counters_seconds
        return {
            "storage_tier": self.tier,
            "passes": len(passes),
            "seconds": wall_seconds,
            "active_read_seconds": active_seconds,
            "counter_window_seconds": counters_seconds,
            "cache_control_seconds": control_seconds,
            "cache_control_fraction": control_seconds / wall_seconds,
            "other_control_seconds": wall_seconds - active_seconds - control_seconds,
            "cache_mode": "client cold before every pass; server cache uncontrolled"
            if self.tier == "nfs"
            else "cold before every pass",
            "storage_bytes": storage_bytes,
            "storage_gib_s": storage_bytes / wall_seconds / base.GIB
            if storage_bytes is not None
            else None,
            "process_io": wall_delta["process_io"],
            "wall_device_io": wall_delta["devices"],
            "device_io": {
                device: total([row["device_io"][device] for row in passes])
                for device in wall_delta["devices"]
            },
            "nfs_io": nfs,
            "wall_nfs_io": wall_delta["nfs"],
            "nfs_payload_read_bytes": nfs["payload_read_bytes"],
            "nfs_payload_gib_s": active_payload_rate / base.GIB,
            "nfs_read_operations_s": nfs_ops / counters_seconds,
            "nfs_payload_bytes_per_read": nfs["payload_read_bytes"] / nfs_ops
            if nfs_ops
            else None,
            "nfs_read_queue_ms": nfs["READ.queue_milliseconds"] / nfs_ops
            if nfs_ops
            else None,
            "nfs_read_rtt_ms": nfs["READ.rtt_milliseconds"] / nfs_ops
            if nfs_ops
            else None,
            "nfs_read_execute_ms": nfs["READ.execute_milliseconds"] / nfs_ops
            if nfs_ops
            else None,
            "nfs_read_retransmissions": nfs["READ.transmissions"] - nfs_ops,
            "nfs_read_errors": nfs.get("READ.errors"),
            "nfs_idle_before": idle_before,
            "nfs_idle_after": idle_after,
            "nfs_idle_max_gib_s": idle_payload_rate / base.GIB,
            "nfs_idle_fraction_of_active": idle_payload_rate / active_payload_rate
            if active_payload_rate
            else None,
            "cpu": total([row["cpu"] for row in passes]),
            "minimum_storage_bytes_per_pass": minimum_storage_bytes,
            "minimum_read_bytes_scope": "process local block reads"
            if self.tier == "local"
            else "shared NFS client payload; consistency check only",
            "pass_details": passes,
            "resident_pages_after": self.residency(),
        }
