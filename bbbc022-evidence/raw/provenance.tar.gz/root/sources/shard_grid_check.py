"""Check query coverage, cross-shard crops, and read-overlap accounting."""

import copy
import csv
import math
import struct
import tempfile
from collections import Counter
from pathlib import Path

import cpu_pareto as base
import numpy as np
import shard_grid_data as grid
from shard_grid_measure import check_stats, trace_summary
from shard_grid_readers import (
    tensorstore_context,
    tensorstore_crops,
    tensorstore_submit,
)
from shard_grid_report import collect


def check_queries():
    shape = grid.volume_shape(grid.SHARD_SHAPE)
    assert math.prod(shape) * 2 == 16 * base.GIB
    assert math.prod(grid.SHARD_SHAPE) * 2 == base.GIB
    workloads = grid.query_workloads(grid.SHARD_SHAPE, 16384)
    for workload in workloads:
        sample_shape = workload["sample_shape"]
        assert len(workload["queries"]) == 16384
        for start in workload["queries"]:
            assert all(
                0 <= a <= n - q
                for a, n, q in zip(start, shape, sample_shape, strict=True)
            )
        for first in range(0, 16384, 128):
            origins = Counter(
                tuple(a // b for a, b in zip(start, grid.SHARD_SHAPE, strict=True))
                for start in workload["queries"][first : first + 128]
            )
            assert set(origins) == set(grid.coordinates())
            assert set(origins.values()) == {8}
    full = workloads[2]
    tiles = {
        tuple(a // b for a, b in zip(start, base.SAMPLE_SHAPE, strict=True))
        for start in full["queries"]
    }
    assert len(tiles) == 16384
    counts = Counter(
        len(grid.intersected_shards(start, grid.CROP_SHAPE, grid.SHARD_SHAPE))
        for start in workloads[0]["queries"]
    )
    assert set(counts) == {1, 2, 4}
    print("Query coverage and complete tiling:", dict(sorted(counts.items())))


def check_crop_assembly(root):
    shard_shape = (2, 8, 8)
    shape = (2, 32, 32)
    source = np.arange(math.prod(shape), dtype=np.uint16).reshape(shape)
    folder = root / "known"
    folder.mkdir()
    for coordinate in grid.coordinates():
        selection = tuple(
            slice(a * n, (a + 1) * n)
            for a, n in zip(coordinate, shard_shape, strict=True)
        )
        np.save(
            folder / grid.source_name(coordinate), source[selection], allow_pickle=False
        )
    for start in ((0, 0, 0), (1, 6, 6), (1, 7, 7), (1, 27, 27)):
        crop_shape = (1, 5, 5)
        actual = grid.expected_crop(root, "known", start, crop_shape, shard_shape)
        expected = source[
            tuple(slice(a, a + n) for a, n in zip(start, crop_shape, strict=True))
        ].astype(np.float32)
        np.testing.assert_array_equal(actual, expected)
    print("Known-value crops within shards and across four-shard intersections: passed")


def check_chunk_accounting(root):
    rows = []
    for coordinate in grid.coordinates():
        relative = Path("volume/c", *map(str, coordinate))
        path = root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(b"\0" * 333 + struct.pack("<QQI", 0, 333, 0))
        rows.append(
            {
                "coordinate": coordinate,
                "path": str(relative),
                "file_bytes": 353,
                "index_bytes": 20,
            }
        )
    audit = {"case": {"chunk_kib": 16}, "shard_shape": (1, 64, 128), "shards": rows}
    workload = {
        "queries": [(0, 32, 64), (0, 32, 64)],
        "sample_shape": (1, 64, 128),
        "samples_per_batch": 2,
        "logical_bytes_per_pass": 2 * 16384,
    }
    result = grid.geometry(root, audit, workload, 4096)
    assert result["unique_chunks_per_pass"] == 4
    assert result["chunk_uses_per_pass"] == 8
    assert result["encoded_bytes_per_pass"] == 4 * 333
    assert result["decoded_bytes_per_pass"] == 4 * 16384
    assert result["decoded_per_useful_byte"] == 2
    assert result["min_shards_per_batch"] == result["max_shards_per_batch"] == 4
    assert result["queries_crossing_shard_boundaries"] == 2
    print("Cross-shard chunk counts and sharing within a batch: passed")


def check_trace(root):
    path = root / "trace.csv"
    with path.open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            (
                "start_ns",
                "end_ns",
                "shard",
                "requested_bytes",
                "returned_bytes",
                "offset",
            )
        )
        writer.writerows(((0, 10, 0, 1, 1, 0), (2, 6, 1, 1, 1, 0), (4, 8, 0, 1, 1, 1)))
    summary = trace_summary(path, [(0, 0, 2), (1, 0, 1)])
    assert summary["verified_chunk_ranges"] == 2
    try:
        trace_summary(path, [(1, 0, 2)])
    except RuntimeError:
        pass
    else:
        raise AssertionError("accepted an unread chunk range")
    assert summary["peak_concurrent_shards"] == 2
    assert abs(summary["mean_concurrent_shards"] - 1.4) < 1e-12
    assert summary["shards_read"] == 2
    assert summary["seconds_by_concurrent_shards"]["1"] == 6e-9
    assert summary["seconds_by_concurrent_shards"]["2"] == 4e-9
    print("Distinct-shard overlap and rejection of omitted chunk payloads: passed")


def check_tensorstore_output():
    import tensorstore as ts

    source = np.arange(2 * 32 * 32, dtype=np.uint16).reshape((2, 32, 32))
    context = ts.Context(tensorstore_context(32, 16))
    array = ts.array(source, context=context).astype(ts.float32)
    starts = [(0, 0, 0), (1, 6, 6), (1, 7, 7), (1, 27, 27)]
    shape = (1, 5, 5)
    layers = tensorstore_crops(array, starts, shape)
    actual = tensorstore_submit(layers, context).result()
    expected = np.stack(
        [
            source[tuple(slice(a, a + n) for a, n in zip(start, shape, strict=True))]
            for start in starts
        ]
    ).astype(np.float32)
    np.testing.assert_array_equal(actual, expected)
    assert actual.dtype == np.float32 and actual.flags.c_contiguous
    assert actual.shape == (4, 1, 5, 5)
    print(
        "TensorStore batch order, coordinate translation, float32 conversion and contiguous output: passed"
    )


def check_rate_accounting():
    row = {
        "passes": 2,
        "active_read_seconds": 2,
        "seconds": 5,
        "storage_bytes": 250,
        "pass_details": [
            {"process_io": {"read_bytes": 80}},
            {"process_io": {"read_bytes": 120}},
        ],
    }
    stats = {
        "file_metrics": {"/tensorstore/kvstore/file/bytes_read": 160},
        "output_bytes": 400,
    }
    expected = {"encoded_bytes_per_pass": 70, "decoded_bytes_per_pass": 300}
    workload = {"logical_bytes_per_pass": 100}
    check_stats("tensorstore", stats, row, expected, workload)
    assert row["storage_per_useful_byte"] == 1
    assert row["output_float32_active_gib_s"] * base.GIB == 200
    assert row["storage_active_gib_s"] * base.GIB == 100
    assert row["storage_wall_gib_s"] * base.GIB == 50
    assert row["geometric_decoded_per_useful_byte"] == 3
    assert row["decoded_bytes"] is None and row["decoded_active_gib_s"] is None
    print(
        "Active versus wall rates, storage amplification, and unavailable decode counters: passed"
    )


def check_pairing(root):
    folder = root / "pairing"
    folder.mkdir()
    base.write_json(folder / "manifest.json", {"repeats": 1})
    base.write_json(
        folder / "complete.json", {"results": ["damacy.json", "tensorstore.json"]}
    )
    run = {
        "case": {"input": "known", "codec": "lz4", "chunk_kib": 16, "block_kib": 16},
        "workload": "aligned",
        "cache": "cold",
        "diagnostic_only": False,
        "workers": 32,
        "io_workers": 16,
        "stored_bytes": 100,
        "raw_volume_bytes": 200,
        "backend_settings": {
            "decode_workers": 32,
            "file_reader_workers": 16,
            "blosc_internal_threads": 1,
            "output_dtype": "float32",
        },
        "audit_sha256": "same data",
        "references_sha256": "same queries",
        "volume_shape": [2, 32, 32],
        "shard_shape": [2, 8, 8],
        "shard_grid": [1, 4, 4],
        "sample_shape": [1, 5, 5],
        "samples_per_batch": 4,
        "query_count": 4,
        "geometry": {
            "min_shards_per_batch": 16,
            "queries_crossing_shard_boundaries": 2,
        },
        "storage": {},
        "environment": {"hostname": "test", "affinity": list(range(48))},
    }
    from shard_grid_report import RATE_FIELDS

    for backend, rate in (("damacy", 2.0), ("tensorstore", 1.0)):
        row = {field: rate for field in RATE_FIELDS}
        row.update({"repeat": 1, "passes": 1, "active_read_seconds": 1, "seconds": 1})
        run["backend"] = backend
        run["measurements"] = [row]
        base.write_json(folder / f"{backend}.json", run)
    _, pairs, _ = collect(folder)
    assert pairs[0]["damacy_over_tensorstore_output_rate"] == 2
    for key, value in (
        ("workers", 16),
        ("audit_sha256", "different data"),
        ("references_sha256", "different queries"),
    ):
        changed = copy.deepcopy(run)
        changed[key] = value
        base.write_json(folder / "tensorstore.json", changed)
        try:
            collect(folder)
        except RuntimeError:
            pass
        else:
            raise AssertionError(f"accepted unmatched {key}")
    print(
        "Paired rate ratio and rejection of mismatched threads, data or queries: passed"
    )


if __name__ == "__main__":
    check_queries()
    check_tensorstore_output()
    check_rate_accounting()
    with tempfile.TemporaryDirectory(prefix="damacy-grid-check-") as name:
        root = Path(name)
        check_crop_assembly(root)
        check_chunk_accounting(root)
        check_trace(root)
        check_pairing(root)
