"""Measure a CPU pipeline reading one array with sixteen shards."""

import argparse
import csv
import ctypes
import math
import os
import resource
import statistics
from collections import Counter, defaultdict
from pathlib import Path

import cpu_pareto as base
import shard_grid_data as grid
import shard_grid_readers as readers
import storage_reads as storage
from cold_read_config import SETTINGS, VARIANTS
from read_model import read_geometry


def trace_summary(path, required_ranges=None, bounds=None):
    events = []
    ranges = defaultdict(list)
    total = Counter()
    with path.open() as stream:
        for row in csv.DictReader(stream):
            start, end = int(row["start_ns"]), int(row["end_ns"])
            shard = int(row["shard"])
            base.require(end >= start, "negative traced read duration")
            base.require(
                int(row["returned_bytes"]) == int(row["requested_bytes"]),
                "incomplete traced read",
            )
            if required_ranges is not None:
                offset = int(row["offset"])
                ranges[shard].append((offset, offset + int(row["returned_bytes"])))
            events.extend(((start, 1, shard), (end, -1, shard)))
            total[shard] += 1
    base.require(events, "no shard reads were traced")
    if required_ranges is not None:
        covered = {}
        for shard, spans in ranges.items():
            merged = []
            for start, end in sorted(spans):
                if merged and start <= merged[-1][1]:
                    merged[-1][1] = max(end, merged[-1][1])
                else:
                    merged.append([start, end])
            covered[shard] = merged
        missing = [
            [shard, offset, size]
            for shard, offset, size in required_ranges
            if not any(
                start <= offset and end >= offset + size
                for start, end in covered.get(shard, [])
            )
        ]
        base.require(
            not missing,
            f"diagnostic omitted {len(missing)} required chunk ranges: {missing[:4]}",
        )
    first = min(row[0] for row in events)
    last = max(row[0] for row in events)
    begin, end = bounds if bounds is not None else (first, last)
    base.require(begin <= first <= last <= end, "reads outside the trace window")
    active = Counter()
    histogram = Counter()
    call_histogram = Counter()
    gaps = []
    previous = begin
    peak = peak_calls = calls = 0
    for now, change, shard in sorted(events):
        elapsed = now - previous
        histogram[len(active)] += elapsed
        call_histogram[calls] += elapsed
        if not calls and elapsed and previous >= first:
            gaps.append(elapsed)
        calls += change
        active[shard] += change
        base.require(
            active[shard] >= 0 and calls >= 0, "trace completion without read start"
        )
        if active[shard] == 0:
            del active[shard]
        peak = max(peak, len(active))
        peak_calls = max(peak_calls, calls)
        previous = now
    base.require(not active and not calls, "trace has unfinished reads")
    histogram[0] += end - previous
    call_histogram[0] += end - previous
    duration = end - begin
    base.require(duration > 0, "empty trace duration")
    base.require(
        sum(histogram.values()) == sum(call_histogram.values()) == duration,
        "incomplete trace intervals",
    )
    return {
        "diagnostic_only": True,
        "verified_chunk_ranges": len(required_ranges)
        if required_ranges is not None
        else None,
        "scope": "application pread calls over the entire traced read, including leading and trailing work; kernel readahead and device queues are not traced; separate from throughput runs",
        "shards_read": len(total),
        "reads_per_shard": dict(sorted(total.items())),
        "peak_concurrent_shards": peak,
        "mean_concurrent_shards": sum(k * v for k, v in histogram.items()) / duration,
        "fraction_at_sixteen_shards": histogram[16] / duration,
        "seconds_by_concurrent_shards": {
            str(k): v / 1e9 for k, v in sorted(histogram.items())
        },
        "peak_active_file_reads": peak_calls,
        "mean_active_file_reads": sum(k * v for k, v in call_histogram.items())
        / duration,
        "fraction_no_file_reads": call_histogram[0] / duration,
        "seconds_by_active_file_reads": {
            str(k): v / 1e9 for k, v in sorted(call_histogram.items())
        },
        "between_read_gap_count": len(gaps),
        "longest_between_read_gap_seconds": max(gaps, default=0) / 1e9,
        "median_between_read_gap_seconds": statistics.median(gaps) / 1e9 if gaps else 0,
        "trace_start_ns": begin,
        "trace_end_ns": end,
        "trace_seconds": duration / 1e9,
        "read_span_seconds": (last - first) / 1e9,
    }


def check_stats(backend, stats, row, expected, workload, merged=False):
    passes = row["passes"]
    useful = passes * workload["logical_bytes_per_pass"]
    geometric_encoded = passes * expected["encoded_bytes_per_pass"]
    geometric_decoded = passes * expected["decoded_bytes_per_pass"]
    decoded = None
    if backend == "damacy":
        chunks = passes * expected["unique_chunks_per_pass"]
        base.require(stats["chunks_dispatched"] == chunks, "chunk count mismatch")
        expected_reads = (
            passes * expected["merged_reads_per_pass"] if merged else chunks
        )
        expected_reader_bytes = (
            passes * expected["merged_reader_bytes_per_pass"]
            if merged
            else geometric_encoded
        )
        base.require(stats["reads_issued"] == expected_reads, "read count mismatch")
        base.require(
            stats["io"]["input_bytes"] == expected_reader_bytes,
            "reader byte count mismatch",
        )
        base.require(
            stats["decode"]["input_bytes"] == geometric_encoded,
            "encoded byte count mismatch",
        )
        base.require(
            stats["decode"]["output_bytes"]
            == stats["assemble"]["input_bytes"]
            == geometric_decoded,
            "decoded byte count mismatch",
        )
        base.require(stats["gpu_bytes_committed"] == 0, "GPU memory was used")
        reader_bytes = stats["io"]["input_bytes"]
        decoded = stats["decode"]["output_bytes"]
        output_bytes = stats["assemble"]["output_bytes"]
    else:
        reader_bytes = stats["file_metrics"]["/tensorstore/kvstore/file/bytes_read"]
        output_bytes = stats["output_bytes"]
        base.require(reader_bytes > 0, "TensorStore read no file bytes")
    base.require(output_bytes == 2 * useful, "float32 output count mismatch")
    active_storage = (
        None
        if row.get("storage_tier") == "nfs"
        else sum(p["process_io"]["read_bytes"] for p in row["pass_details"])
    )
    row.update(
        {
            "active_storage_bytes": active_storage,
            "useful_bytes": useful,
            "reader_bytes": reader_bytes,
            "decoded_bytes": decoded,
            "output_bytes": output_bytes,
            "geometric_encoded_bytes": geometric_encoded,
            "geometric_decoded_bytes": geometric_decoded,
            "geometric_decoded_per_useful_byte": geometric_decoded / useful,
            "decoded_per_useful_byte": None if decoded is None else decoded / useful,
            "reader_per_useful_byte": reader_bytes / useful,
            "storage_per_useful_byte": None
            if active_storage is None
            else active_storage / useful,
            "stats": stats,
        }
    )
    for field, count in (
        ("storage", active_storage),
        ("reader", reader_bytes),
        ("decoded", decoded),
        ("useful_uint16", useful),
        ("output_float32", output_bytes),
    ):
        row[field + "_active_gib_s"] = (
            None if count is None else count / row["active_read_seconds"] / base.GIB
        )
        wall_count = row["storage_bytes"] if field == "storage" else count
        row[field + "_wall_gib_s"] = (
            None if wall_count is None else wall_count / row["seconds"] / base.GIB
        )


def check_file_stats(implementation, stats, row, workload, chunk_bytes):
    batches = row["passes"] * len(workload["queries"]) // workload["samples_per_batch"]
    if implementation == "tensorstore":
        opens = stats["file_metrics"]["/tensorstore/kvstore/file/open_read"]
        base.require(opens == 16 * batches, "TensorStore file-open count changed")
        return
    configured = SETTINGS[implementation]
    cpu = stats["cpu_read_buffers"]
    base.require(
        cpu["decode_workers"] == 32
        and cpu["input_buffers"] == 2
        and cpu["read_buffer_chunks"] == configured["read_buffer_chunks"]
        and cpu["encoded_bytes_per_buffer"]
        == configured["read_buffer_chunks"] * (chunk_bytes + 16),
        "native read-buffer capacity or worker count changed",
    )
    handles, advice = configured["file_read_mode"].split("-")
    delta, total = stats["file_reader"], stats["file_reader_total"]
    fresh, random = handles == "batch", advice == "random"
    base.require(
        total["handles"] == handles and total["readahead"] == advice,
        "reader used the wrong mode",
    )
    base.require(
        total["read_active"] == total["active_batches"] == 0, "unfinished reads"
    )
    base.require(total["read_max_active"] <= 16, "extra file-reading workers")
    base.require(total["random_advice_errors"] == 0, "readahead hint failed")
    base.require(
        total["random_advice_calls"] == (total["opens"] if random else 0),
        "readahead hint was not applied to every reader handle",
    )
    base.require(delta["read_jobs"] == stats["reads_issued"], "file read count differs")
    base.require(
        delta["opens"] == (16 * batches if fresh else 0), "wrong handle lifetime"
    )
    base.require(delta["closes"] == delta["opens"], "timed handles were not closed")
    base.require(
        delta["batches_created"]
        == delta["batches_destroyed"]
        == (batches if fresh else 0),
        "incorrect per-batch handle cleanup",
    )
    base.require(
        total["open_files"] == (0 if fresh else 16), "unexpected retained handles"
    )
    base.require(total["opens"] - total["closes"] == total["open_files"], "handle leak")
    base.require(
        total["max_open_files"] <= (32 if fresh else 16), "too many open shards"
    )
    base.require(
        total["max_active_batches"] <= (2 if fresh else 0), "extra active batches"
    )
    if not fresh:
        base.require(total["opens"] == 16, "persistent handles were reopened")


def measure(args):
    base.require(
        os.environ.get("SLURM_JOB_ID"), "measurement requires a compute allocation"
    )
    base.require(
        base.physical_cpus() == len(os.sched_getaffinity(0)) == args.cores,
        "unexpected physical CPU allocation",
    )
    base.require(
        args.cores >= args.workers + args.io_workers,
        "insufficient physical cores for worker counts",
    )
    audit = base.read_json(args.audit)
    references = base.read_json(args.references)
    base.require(
        references["source_sha256"]
        == [row["source_sha256"] for row in audit["shards"]],
        "query sources changed",
    )
    workload = next(
        row for row in references["workloads"] if row["name"] == args.workload
    ).copy()
    if args.query_limit:
        base.require(args.trace, "query limit is only for the concurrency diagnostic")
        base.require(
            args.query_limit % workload["samples_per_batch"] == 0,
            "partial diagnostic batch",
        )
        workload["queries"] = workload["queries"][: args.query_limit]
        workload["float32_sha256"] = {
            k: v
            for k, v in workload["float32_sha256"].items()
            if int(k) < len(workload["queries"])
        }
        workload["logical_bytes_per_pass"] = (
            len(workload["queries"]) * math.prod(workload["sample_shape"]) * 2
        )
    expected = grid.geometry(
        args.data, audit, workload, storage.PAGE, include_ranges=bool(args.trace)
    )
    expected.update(read_geometry(args.data, audit, workload, args.workers))
    base.require(
        expected["min_shards_per_batch"] == 16,
        "batch does not touch all sixteen shards",
    )
    batch_samples = workload["samples_per_batch"]
    base.require(len(workload["queries"]) % batch_samples == 0, "partial batch")
    chunk_bytes = audit["case"]["chunk_kib"] * 1024
    uri = str(args.data / audit["array_path"])

    paths = [args.data / row["path"] for row in audit["shards"]]
    trace = None
    if args.trace:
        trace = ctypes.CDLL(None)
        trace.shard_trace_begin.restype = ctypes.c_int
        trace.shard_trace_end.restype = ctypes.c_int
        trace.shard_trace_start_ns.restype = ctypes.c_uint64
        trace.shard_trace_end_ns.restype = ctypes.c_uint64
    rows = []
    with (
        storage.Files(paths) as files,
        readers.open_reader(
            args.backend,
            uri,
            workload,
            expected,
            chunk_bytes,
            args.workers,
            args.io_workers,
        ) as reader,
    ):
        read = reader.prepare(workload["queries"], workload["sample_shape"])
        checked = 0
        if workload["sample_shape"] == list(grid.CROP_SHAPE):
            validation = references["validation"]
            checked += reader.prepare(
                validation["queries"], validation["sample_shape"]
            )(validation["float32_sha256"])
        checked += read(workload["float32_sha256"])
        description = files.description()

        def prepare_pass():
            nonlocal read
            if args.backend == "tensorstore":
                reader.reset_data_cache()
                read = reader.prepare(workload["queries"], workload["sample_shape"])

        def scan():
            if trace:
                base.require(trace.shard_trace_begin() == 0, "trace setup failed")
            read({})
            if trace:
                base.require(
                    trace.shard_trace_end() == 0,
                    "trace write failed or buffer overflowed",
                )

        for repeat in range(1 if args.trace else args.repeats):
            reader.stats_reset()
            row = files.measure(
                scan,
                cold=args.cache == "cold",
                seconds=0 if args.trace else args.seconds,
                min_useful_bytes=workload["logical_bytes_per_pass"]
                if args.trace
                else args.min_gib * base.GIB,
                useful_bytes_per_pass=workload["logical_bytes_per_pass"],
                minimum_storage_bytes=expected["minimum_storage_bytes_per_pass"],
                prepare=prepare_pass,
            )
            check_stats(
                args.backend,
                reader.stats(),
                row,
                expected,
                workload,
                args.backend == "damacy",
            )
            check_file_stats(
                args.implementation, row["stats"], row, workload, chunk_bytes
            )
            if (
                args.backend == "damacy"
                and args.workload == "full-scan"
                and audit["logical_bytes"] == 16 * base.GIB
            ):
                capacity = SETTINGS[args.implementation]["read_buffer_chunks"]
                wanted_waves = (
                    row["passes"] * expected["unique_chunks_per_pass"] // capacity
                )
                base.require(
                    row["stats"]["waves_emitted"] == wanted_waves,
                    "full-scan buffer dispatch did not use the selected capacity",
                )
            row["repeat"] = args.repeat_index + repeat
            rows.append(row)
            if not args.trace:
                print(
                    f"{args.backend} {base.case_id(audit['case'])} {args.workload} {row['storage_tier']}: {row['output_float32_active_gib_s']:.3f} float32 GiB/s",
                    flush=True,
                )
        if args.backend == "tensorstore":
            base.require(
                reader.settings["data_cache_resets"]
                == sum(row["passes"] for row in rows),
                "data cache was not reset before every pass",
            )
        if args.trace:
            result = trace_summary(
                args.trace,
                expected["required_chunk_ranges"],
                bounds=(trace.shard_trace_start_ns(), trace.shard_trace_end_ns()),
            )
            base.require(
                result["shards_read"] == 16, "diagnostic did not read all shards"
            )
            base.write_json(args.output.with_name("concurrency.json"), result)
            print(
                f"Concurrency diagnostic: peak {result['peak_concurrent_shards']}, mean {result['mean_concurrent_shards']:.2f} distinct shards in pread",
                flush=True,
            )
    base.write_json(
        args.output,
        {
            "backend": args.backend,
            "implementation": args.implementation,
            "native_identity": base.read_json(args.identity) if args.identity else None,
            "backend_settings": reader.settings,
            "case": audit["case"],
            "stored_bytes": audit["stored_bytes"],
            "raw_volume_bytes": audit["logical_bytes"],
            "compression_ratio": audit["compression_ratio"],
            "workload": args.workload,
            "cache": args.cache,
            "diagnostic_only": bool(args.trace),
            "volume_shape": audit["shape"],
            "shard_shape": audit["shard_shape"],
            "shard_grid": audit["shard_grid"],
            "workers": args.workers,
            "io_workers": args.io_workers,
            "sample_shape": workload["sample_shape"],
            "samples_per_batch": batch_samples,
            "query_count": len(workload["queries"]),
            "checked_samples": checked,
            "geometry": expected,
            "storage": description,
            "measurements": rows,
            "audit_sha256": base.digest(args.audit),
            "references_sha256": base.digest(args.references),
            "environment": base.environment(),
            "peak_rss_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
        },
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("data", "audit", "references", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument(
        "--workload",
        choices=("random-1x256x256", "aligned", "full-scan"),
        required=True,
    )
    parser.add_argument("--cache", choices=("cold",), required=True)
    parser.add_argument("--backend", choices=readers.BACKENDS, required=True)
    parser.add_argument("--implementation", choices=VARIANTS, required=True)
    parser.add_argument("--identity", type=Path)
    parser.add_argument("--workers", type=int, default=32)
    parser.add_argument("--io-workers", type=int, default=16)
    parser.add_argument("--cores", type=int, default=48)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--repeat-index", type=int, default=1)
    parser.add_argument("--seconds", type=float, default=10)
    parser.add_argument("--min-gib", type=float, default=2)
    parser.add_argument("--query-limit", type=int)
    parser.add_argument("--trace", type=Path)
    args = parser.parse_args()
    base.require(
        args.repeats > 0
        and args.repeat_index > 0
        and args.seconds > 0
        and args.min_gib > 0,
        "invalid measurement duration",
    )
    base.require(
        args.workers == 32 and args.io_workers == 16,
        "this protocol fixes 32 decode and 16 reader workers",
    )
    base.require(
        (args.implementation == "tensorstore") == (args.backend == "tensorstore"),
        "backend/revision mismatch",
    )
    if args.identity:
        from damacy import _native

        identity = base.read_json(args.identity)
        base.require(not _native.CUDA_ENABLED, "CUDA-enabled binary")
        base.require(
            base.digest(Path(_native.__file__)) == identity["native_sha256"],
            "wrong native binary",
        )
        base.require(identity["implementation"] == "damacy", "wrong native revision")
        base.require(
            os.environ.get("DAMACY_BENCH_READ_MODE")
            == SETTINGS[args.implementation]["file_read_mode"],
            "file-read mode differs from the measurement label",
        )
    measure(args)


if __name__ == "__main__":
    main()
