#!/usr/bin/env python3
"""Write controlled Blosc shards and measure Damacy CPU reads."""

from __future__ import annotations

import argparse
import ctypes
import dataclasses
import hashlib
import itertools
import json
import math
import mmap
import os
import platform
import random
import resource
import shutil
import struct
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

GIB = 1 << 30
MIB = 1 << 20
SHARD_SHAPE = (512, 1024, 1024)
SAMPLE_SHAPE = (8, 256, 256)
CHUNKS = {
    512: (1, 512, 512),
    16: (1, 64, 128),
    32: (1, 128, 128),
    128: (1, 256, 256),
    64: (1, 128, 256),
    256: (2, 256, 256),
    1024: (8, 256, 256),
}
SEED = 20260916


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def read_json(path):
    return json.loads(Path(path).read_text())


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def case_id(case):
    return f"{case['input']}-{case['codec']}-c{case['chunk_kib']}-b{case['block_kib']}"


def cases():
    result = []
    for codec, chunk_kib in itertools.product(("lz4", "zstd"), CHUNKS):
        for power in range(2, 11):
            block_kib = 1 << power
            if block_kib <= chunk_kib:
                result.append(
                    {
                        "input": "random12",
                        "codec": codec,
                        "chunk_kib": chunk_kib,
                        "block_kib": block_kib,
                        "group": "sweep",
                    }
                )
    random.Random(SEED).shuffle(result)
    pilot = [
        {
            "input": fill,
            "codec": codec,
            "chunk_kib": 256,
            "block_kib": 64,
            "group": "input_check",
        }
        for fill in ("zeros", "random16")
        for codec in ("lz4", "zstd")
    ]
    return pilot + result


def grid(shape):
    return list(
        itertools.product(
            *(
                range(0, extent, step)
                for extent, step in zip(shape, SAMPLE_SHAPE, strict=True)
            )
        )
    )


def slices(start):
    return tuple(
        slice(begin, begin + size)
        for begin, size in zip(start, SAMPLE_SHAPE, strict=True)
    )


def array_data(fill, shape, seed):
    import numpy as np

    if fill == "zeros":
        return np.zeros(shape, dtype=np.uint16)
    high = 4096 if fill == "random12" else 65536
    return np.random.default_rng(seed).integers(0, high, shape, dtype=np.uint16)


def tensorstore_spec(path, case, shape, shard_shape=None):
    return {
        "driver": "zarr3",
        "kvstore": {"driver": "file", "path": str(path)},
        "store_data_equal_to_fill_value": True,
        "metadata": {
            "zarr_format": 3,
            "node_type": "array",
            "shape": list(shape),
            "data_type": "uint16",
            "fill_value": 0,
            "chunk_grid": {
                "name": "regular",
                "configuration": {"chunk_shape": list(shard_shape or shape)},
            },
            "chunk_key_encoding": {
                "name": "default",
                "configuration": {"separator": "/"},
            },
            "codecs": [
                {
                    "name": "sharding_indexed",
                    "configuration": {
                        "chunk_shape": list(CHUNKS[case["chunk_kib"]]),
                        "codecs": [
                            {"name": "bytes", "configuration": {"endian": "little"}},
                            {
                                "name": "blosc",
                                "configuration": {
                                    "cname": case["codec"],
                                    "clevel": 3,
                                    "typesize": 2,
                                    "shuffle": "bitshuffle",
                                    "blocksize": case["block_kib"] * 1024,
                                },
                            },
                        ],
                        "index_codecs": [
                            {"name": "bytes", "configuration": {"endian": "little"}},
                            {"name": "crc32c"},
                        ],
                        "index_location": "end",
                    },
                }
            ],
        },
    }


def write_shard(path, source, case, coordinate=(0, 0, 0)):
    import google_crc32c
    import numpy as np

    library = ctypes.CDLL("libblosc.so.1")
    library.blosc_set_splitmode.argtypes = [ctypes.c_int]
    library.blosc_set_splitmode.restype = None
    library.blosc_set_splitmode(2)
    library.blosc_get_version_string.restype = ctypes.c_char_p
    compress = library.blosc_compress_ctx
    compress.argtypes = [
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_size_t,
        ctypes.c_size_t,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_size_t,
        ctypes.c_char_p,
        ctypes.c_size_t,
        ctypes.c_int,
    ]
    compress.restype = ctypes.c_int
    chunk = CHUNKS[case["chunk_kib"]]
    counts = tuple(size // part for size, part in zip(source.shape, chunk, strict=True))
    view = source.reshape(
        counts[0], chunk[0], counts[1], chunk[1], counts[2], chunk[2]
    ).transpose(0, 2, 4, 1, 3, 5)

    def encode(coordinate):
        data = np.ascontiguousarray(view[coordinate])
        buffer = ctypes.create_string_buffer(data.nbytes + 16)
        size = compress(
            3,
            2,
            2,
            data.nbytes,
            data.ctypes.data,
            buffer,
            len(buffer),
            case["codec"].encode(),
            case["block_kib"] * 1024,
            1,
        )
        require(0 < size <= len(buffer), f"Blosc compression failed: {size}")
        return bytes(memoryview(buffer).cast("B")[:size])

    destination = path / "c" / Path(*map(str, coordinate))
    destination.parent.mkdir(parents=True, exist_ok=True)
    coordinates = itertools.product(*(range(count) for count in counts))
    index = bytearray()
    offset = 0
    with destination.open("xb") as stream, ThreadPoolExecutor(max_workers=32) as pool:
        while group := list(itertools.islice(coordinates, 128)):
            for encoded in pool.map(encode, group):
                stream.write(encoded)
                index.extend(struct.pack("<QQ", offset, len(encoded)))
                offset += len(encoded)
        stream.write(index)
        stream.write(struct.pack("<I", google_crc32c.value(bytes(index))))
    return {
        "payload_writer": "C-Blosc",
        "blosc_version": library.blosc_get_version_string().decode(),
        "split_mode": "never",
        "compression_workers": 32,
        "internal_threads": 1,
    }


def audit_array(path, case, shape, coordinate=(0, 0, 0)):
    import google_crc32c

    shard = path / "c" / Path(*map(str, coordinate))
    chunk_bytes = case["chunk_kib"] * 1024
    count = math.prod(shape) * 2 // chunk_bytes
    index_bytes = count * 16 + 4
    size = shard.stat().st_size
    blocks, flags_seen, codecs_seen = set(), set(), set()
    memcpy_chunks = 0
    total = 0
    with (
        shard.open("rb") as stream,
        mmap.mmap(stream.fileno(), 0, access=mmap.ACCESS_READ) as data,
    ):
        index = data[-index_bytes:-4]
        expected_crc = struct.unpack("<I", data[-4:])[0]
        require(google_crc32c.value(index) == expected_crc, "bad shard index CRC")
        intervals = []
        for offset, encoded in struct.iter_unpack("<QQ", index):
            require(offset != (1 << 64) - 1, "writer omitted a fill chunk")
            require(
                encoded >= 16 and offset + encoded <= size - index_bytes,
                "invalid encoded chunk range",
            )
            version, _, flags, typesize, raw, block, stored = struct.unpack_from(
                "<BBBBIII", data, offset
            )
            require(version == 2 and typesize == 2, "unexpected Blosc format")
            require(raw == chunk_bytes and stored == encoded, "wrong chunk size")
            require(
                block == case["block_kib"] * 1024,
                f"block request changed: requested {case['block_kib'] * 1024}, actual {block}",
            )
            copied = bool(flags & 2)
            if not copied:
                require(flags & 4, "bitshuffle flag is missing")
                require(flags & 16, "Blosc unexpectedly split a block")
                expected_codec = 1 if case["codec"] == "lz4" else 4
                require(flags >> 5 == expected_codec, "wrong Blosc codec")
            memcpy_chunks += copied
            blocks.add(block)
            flags_seen.add(flags)
            codecs_seen.add(flags >> 5)
            intervals.append((offset, offset + encoded))
            total += encoded
        intervals.sort()
        require(
            intervals[0][0] == 0 and intervals[-1][1] == size - index_bytes,
            "unexpected shard payload boundary",
        )
        require(
            all(left[1] == right[0] for left, right in itertools.pairwise(intervals)),
            "overlapping or unused payload ranges",
        )
    return {
        "path": str(shard.relative_to(path.parent)),
        "file_bytes": size,
        "encoded_chunk_bytes": total,
        "index_bytes": index_bytes,
        "chunks": count,
        "actual_block_bytes": sorted(blocks),
        "blosc_flags": sorted(flags_seen),
        "blosc_codec_ids": sorted(codecs_seen),
        "memcpy_chunks": memcpy_chunks,
        "sha256": digest(shard),
    }


def generate(case_path, data_root, audit_path, shards, small=False):
    import numpy as np
    import tensorstore as ts

    case = read_json(case_path)
    shape = (8, 512, 512) if small else SHARD_SHAPE
    data_root.mkdir(parents=True, exist_ok=False)
    context = ts.Context(
        {
            "data_copy_concurrency": {"limit": 32},
            "file_io_concurrency": {"limit": 8},
            "cache_pool": {"total_bytes_limit": 0},
        }
    )
    audits = []
    started = time.perf_counter()
    positions = grid(shape)
    for shard_index in range(shards):
        path = data_root / f"s{shard_index:03d}"
        source = array_data(case["input"], shape, SEED + shard_index)
        store = ts.open(
            tensorstore_spec(path, case, shape), create=True, context=context
        ).result()
        writer = write_shard(path, source, case)
        decoded = store.read().result()
        require(np.array_equal(source, decoded), "TensorStore full readback failed")
        del decoded
        audit = audit_array(path, case, shape)
        audit["writer"] = writer
        audit["source_sha256"] = hashlib.sha256(memoryview(source)).hexdigest()
        checks = {}
        check_step = max(1, len(positions) // 32)
        for sample_index in sorted(
            set(range(0, len(positions), check_step)) | {len(positions) - 1}
        ):
            expected = source[slices(positions[sample_index])].astype(np.float32)
            checks[str(sample_index)] = hashlib.sha256(
                expected.tobytes(order="C")
            ).hexdigest()
        audit["float32_sample_sha256"] = checks
        audits.append(audit)
        del source, store
    total_bytes = sum(item["file_bytes"] for item in audits)
    logical_bytes = math.prod(shape) * 2 * shards
    write_json(
        audit_path,
        {
            "case": case,
            "shape": shape,
            "shards": audits,
            "logical_bytes": logical_bytes,
            "stored_bytes": total_bytes,
            "compression_ratio": logical_bytes / total_bytes,
            "generation_seconds": time.perf_counter() - started,
            "tensorstore_full_readback": True,
        },
    )


def physical_cpus():
    result = set()
    for cpu in os.sched_getaffinity(0):
        root = Path(f"/sys/devices/system/cpu/cpu{cpu}/topology")
        result.add(
            (
                (root / "physical_package_id").read_text().strip(),
                (root / "core_id").read_text().strip(),
            )
        )
    return len(result)


def environment():
    from importlib.metadata import version

    return {
        "hostname": platform.node(),
        "platform": platform.platform(),
        "python": sys.version,
        "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
        "affinity": sorted(os.sched_getaffinity(0)),
        "physical_cores": physical_cpus(),
        "versions": {
            package: version(package)
            for package in ("numpy", "tensorstore", "google-crc32c")
        },
        "lscpu": subprocess.check_output(["lscpu"], text=True),
    }


def measure(args):
    import damacy
    import numpy as np

    require(os.environ.get("SLURM_JOB_ID"), "measurements need a Slurm allocation")
    require(physical_cpus() >= args.workers, "not enough physical CPU cores")
    audit = read_json(args.audit)
    case = audit["case"]
    shape = tuple(audit["shape"])
    positions = grid(shape)
    batch_samples = min(128, len(positions))
    require(len(positions) % batch_samples == 0, "incomplete output batch")
    samples = [
        damacy.Sample(
            str(args.data / f"s{shard_index:03d}"),
            [
                (start, start + size)
                for start, size in zip(position, SAMPLE_SHAPE, strict=True)
            ],
        )
        for shard_index in range(len(audit["shards"]))
        for position in positions
    ]
    chunk_bytes = case["chunk_kib"] * 1024
    lookahead = 4 * batch_samples
    metadata = damacy.ZarrMetadata(
        reader=damacy.FileMetadataReader(concurrency=8),
        cache=damacy.MetadataCache(array_entries=1024, shard_index_entries=1024),
    )
    damacy.set_log_level(damacy.LOG_WARN)
    results = []
    with damacy.Pipeline(
        planner=damacy.ChunkPlanner(
            metadata=metadata,
            limits=damacy.PlanLimits(
                max_chunks=16384,
                max_chunk_bytes=MIB,
                max_shards_per_sample=1,
                max_plan_bytes=64 * MIB,
            ),
        ),
        executor=damacy.CpuExecutor(
            reader=damacy.FileReader(workers=args.io_workers, max_inflight_reads=4096),
            limits=damacy.CpuLimits(
                max_memory_bytes=2 * GIB,
                decode_workers=args.workers,
                max_encoded_chunk_bytes=chunk_bytes + 16,
                max_decoded_chunk_bytes=chunk_bytes,
            ),
        ),
        output=damacy.BatchSpec(batch_samples, SAMPLE_SHAPE),
        queues=damacy.QueueLimits(lookahead_samples=lookahead, prepared_batches=2),
        pop_timeout_s=None,
    ) as pipeline:
        require(pipeline.device == -1, "benchmark did not select CPU execution")

        def scan(check=False):
            pipeline.push(samples)
            checked = 0
            for first in range(0, len(samples), batch_samples):
                with pipeline.pop() as batch:
                    if check:
                        values = np.from_dlpack(batch)
                        for local in range(batch_samples):
                            shard_index, sample_index = divmod(
                                first + local, len(positions)
                            )
                            expected = audit["shards"][shard_index][
                                "float32_sample_sha256"
                            ].get(str(sample_index))
                            if expected is not None:
                                actual = hashlib.sha256(
                                    values[local].tobytes(order="C")
                                ).hexdigest()
                                require(
                                    actual == expected,
                                    f"CPU readback mismatch at {shard_index}:{sample_index}",
                                )
                                checked += 1
                        del values
            return checked

        checked = scan(check=True)
        require(checked >= len(audit["shards"]), "no CPU output checks")
        for repeat in range(args.repeats):
            pipeline.stats_reset()
            passes = 0
            started = time.perf_counter()
            while True:
                scan()
                passes += 1
                elapsed = time.perf_counter() - started
                if (
                    elapsed >= args.seconds
                    and passes * audit["logical_bytes"] >= args.min_gib * GIB
                ):
                    break
            stats = dataclasses.asdict(pipeline.stats())
            logical_bytes = passes * audit["logical_bytes"]
            chunks = passes * sum(shard["chunks"] for shard in audit["shards"])
            require(
                int(stats["decode"]["output_bytes"]) == logical_bytes,
                "decoded byte count differs from full scan",
            )
            require(
                int(stats["assemble"]["output_bytes"]) == 2 * logical_bytes,
                "output byte count differs from float32 scan",
            )
            require(stats["chunks_dispatched"] == chunks, "unexpected decoded chunks")
            require(
                stats["reads_issued"] == chunks, "missing reads or cached decoded data"
            )
            require(stats["gpu_bytes_committed"] == 0, "CPU run allocated GPU memory")
            results.append(
                {
                    "repeat": repeat + 1,
                    "passes": passes,
                    "seconds": elapsed,
                    "logical_bytes": logical_bytes,
                    "logical_gib_s": logical_bytes / elapsed / GIB,
                    "float32_gib_s": 2 * logical_bytes / elapsed / GIB,
                    "encoded_gib_s": stats["decode"]["input_bytes"] / elapsed / GIB,
                    "decode_worker_seconds": stats["decode"]["ms"] / 1000,
                    "assemble_worker_seconds": stats["assemble"]["ms"] / 1000,
                    "stats": stats,
                }
            )
            print(
                f"{case_id(case)} repeat {repeat + 1}: "
                f"{results[-1]['logical_gib_s']:.3f} GiB/s",
                flush=True,
            )
    write_json(
        args.output,
        {
            "case": case,
            "audit_sha256": digest(args.audit),
            "workers": args.workers,
            "io_workers": args.io_workers,
            "sample_shape": SAMPLE_SHAPE,
            "samples_per_batch": batch_samples,
            "checked_samples": checked,
            "warmup_full_scans": 1,
            "peak_rss_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
            "environment": environment(),
            "measurements": results,
        },
    )


def plan(args):
    require(args.shards > 0, "shards must be positive")
    require(args.workers > 0 and args.io_workers > 0, "workers must be positive")
    require(
        args.repeats > 0 and args.seconds > 0 and args.min_gib > 0,
        "measurement limits must be positive",
    )
    manifest = {
        "version": 1,
        "source_revision": subprocess.check_output(
            ["git", "rev-parse", "HEAD"],
            text=True,
            cwd=Path(__file__).resolve().parent.parent,
        ).strip(),
        "data_seed": SEED,
        "order_seed": SEED,
        "shard_shape": SHARD_SHAPE,
        "shards": args.shards,
        "logical_shard_bytes": math.prod(SHARD_SHAPE) * 2,
        "sample_shape": SAMPLE_SHAPE,
        "samples_per_batch": 128,
        "workers": args.workers,
        "io_workers": args.io_workers,
        "repeats": args.repeats,
        "seconds": args.seconds,
        "min_gib": args.min_gib,
        "writer": "C-Blosc payloads with TensorStore metadata and readback",
        "split_mode": "never",
        "level": 3,
        "shuffle": "bitshuffle",
        "storage": "job-local files, warm OS page cache",
        "read_work": "complete nonoverlapping scans, uint16 input to float32 output",
        "cases": cases(),
    }
    write_json(args.output, manifest)
    print(
        f"{len(manifest['cases'])} cases; {args.repeats} repeats; "
        f"{args.shards} x 1 GiB shards per case"
    )


def child(command, log):
    with log.open("a") as stream:
        subprocess.run(command, check=True, stdout=stream, stderr=subprocess.STDOUT)


def run(args):
    require(os.environ.get("SLURM_JOB_ID"), "sweep needs a Slurm allocation")
    manifest = read_json(args.manifest)
    args.output.mkdir(parents=True, exist_ok=False)
    write_json(args.output / "manifest.json", manifest)
    write_json(args.output / "environment.json", environment())
    script = Path(__file__).resolve()
    dataset = args.data / "array-data"
    args.data.mkdir(parents=True, exist_ok=True)
    require(not dataset.exists(), f"refusing to replace {dataset}")
    all_cases = manifest["cases"]
    for index, case in enumerate(all_cases):
        name = case_id(case)
        output = args.output / name
        output.mkdir()
        case_path = output / "case.json"
        audit_path = output / "audit.json"
        write_json(case_path, case)
        print(f"[{index + 1}/{len(all_cases)}] generating {name}", flush=True)
        command = [
            sys.executable,
            str(script),
            "generate",
            "--case",
            str(case_path),
            "--data",
            str(dataset),
            "--audit",
            str(audit_path),
            "--shards",
            str(1 if args.preflight else manifest["shards"]),
        ]
        if args.preflight:
            command.append("--small")
        child(command, output / "generate.log")
        command = [
            sys.executable,
            str(script),
            "measure",
            "--data",
            str(dataset),
            "--audit",
            str(audit_path),
            "--output",
            str(output / "measurements.json"),
            "--workers",
            str(manifest["workers"]),
            "--io-workers",
            str(manifest["io_workers"]),
            "--repeats",
            str(1 if args.preflight else manifest["repeats"]),
            "--seconds",
            str(0.1 if args.preflight else manifest["seconds"]),
            "--min-gib",
            str(0.01 if args.preflight else manifest["min_gib"]),
        ]
        print(f"[{index + 1}/{len(all_cases)}] reading {name}", flush=True)
        child(command, output / "measure.log")
        print((output / "measure.log").read_text(), end="", flush=True)
        shutil.rmtree(dataset)
    write_json(
        args.output / "completed.json",
        {
            "cases": len(all_cases),
            "finished_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "manifest_sha256": digest(args.output / "manifest.json"),
        },
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    p = commands.add_parser("plan")
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--shards", type=int, default=4)
    p.add_argument("--workers", type=int, default=32)
    p.add_argument("--io-workers", type=int, default=8)
    p.add_argument("--repeats", type=int, default=3)
    p.add_argument("--seconds", type=float, default=3)
    p.add_argument("--min-gib", type=float, default=8)
    p = commands.add_parser("generate")
    p.add_argument("--case", type=Path, required=True)
    p.add_argument("--data", type=Path, required=True)
    p.add_argument("--audit", type=Path, required=True)
    p.add_argument("--shards", type=int, required=True)
    p.add_argument("--small", action="store_true")
    p = commands.add_parser("measure")
    p.add_argument("--data", type=Path, required=True)
    p.add_argument("--audit", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--workers", type=int, default=32)
    p.add_argument("--io-workers", type=int, default=8)
    p.add_argument("--repeats", type=int, default=3)
    p.add_argument("--seconds", type=float, default=3)
    p.add_argument("--min-gib", type=float, default=8)
    p = commands.add_parser("run")
    p.add_argument("--manifest", type=Path, required=True)
    p.add_argument("--data", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--preflight", action="store_true")
    args = parser.parse_args()
    if args.command == "plan":
        plan(args)
    elif args.command == "generate":
        require(os.environ.get("SLURM_JOB_ID"), "generation needs a Slurm allocation")
        generate(args.case, args.data, args.audit, args.shards, args.small)
    elif args.command == "measure":
        measure(args)
    elif args.command == "run":
        run(args)


if __name__ == "__main__":
    main()
