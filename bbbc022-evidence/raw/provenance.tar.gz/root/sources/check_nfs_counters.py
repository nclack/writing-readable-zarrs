"""Check counter parsing and isolation of active read intervals."""

import os

import cpu_pareto as base
import storage_reads as storage


def check_parser():
    text = """device host:/other mounted on /elsewhere with fstype nfs statvers=1.1
 bytes: 1 2 3 4 9999 6 7 8
 READ: 1 1 0 100 1124 1 2 3 0
device host:/data mounted on /mnt/main0 with fstype nfs statvers=1.1
 bytes: 1 2 3 4 5000 6 7 8
 READ: 2 3 0 224 5256 4 8 12 0
device overlay mounted on / with fstype overlay
"""
    parsed = storage.parse_mountstats(text, "/mnt/main0")
    assert parsed["payload_read_bytes"] == 5000
    assert parsed["READ.operations"] == 2
    assert parsed["READ.queue_milliseconds"] == 4
    assert parsed["READ.rtt_milliseconds"] == 8
    assert parsed["READ.execute_milliseconds"] == 12
    for broken in (
        text.replace("READ:", "UNRECOGNIZED:"),
        text.replace("/mnt/main0", "/absent"),
    ):
        try:
            storage.parse_mountstats(broken, "/mnt/main0")
        except RuntimeError:
            pass
        else:
            raise AssertionError("missing NFS counters accepted")
    try:
        storage.difference({"read_bytes": 10}, {"read_bytes": 9})
    except RuntimeError:
        pass
    else:
        raise AssertionError("counter reset accepted")


class SimulatedFiles(storage.Files):
    def __init__(self, payload, tier):
        self.tier, self.payload = tier, payload
        self.value = 0
        self.last_eviction_attempts = 1

    def residency(self):
        return [0] * 16

    def evict(self):
        self.value += 1000
        return self.residency()

    def snapshot(self):
        return {
            "counter_time": self.value + 1,
            "process_io": {"read_bytes": 0},
            "nfs": {
                "payload_read_bytes": self.value,
                "READ.operations": self.value,
                "READ.transmissions": self.value,
                "READ.queue_milliseconds": self.value,
                "READ.rtt_milliseconds": self.value,
                "READ.execute_milliseconds": self.value,
            },
            "devices": {},
            "cpu": {"user_seconds": 0, "system_seconds": 0},
        }

    def idle(self):
        return {"seconds": 1, "nfs": {"payload_read_bytes": 0}}

    def scan(self):
        self.value += self.payload


def check_measurement():
    files = SimulatedFiles(100, "nfs")
    row = files.measure(
        files.scan,
        cold=True,
        seconds=0,
        min_useful_bytes=1,
        useful_bytes_per_pass=1,
        minimum_storage_bytes=100,
    )
    assert row["nfs_payload_read_bytes"] == 100
    assert row["storage_bytes"] is None
    assert row["process_io"]["read_bytes"] == 0
    assert row["wall_nfs_io"]["payload_read_bytes"] == 1100
    assert row["pass_details"][0]["minimum_read_bytes_check"] == 100
    for payload, tier in ((99, "nfs"), (100, "local")):
        files = SimulatedFiles(payload, tier)
        try:
            files.measure(
                files.scan,
                cold=True,
                seconds=0,
                min_useful_bytes=1,
                useful_bytes_per_pass=1,
                minimum_storage_bytes=100,
            )
        except RuntimeError:
            pass
        else:
            raise AssertionError("missing storage reads accepted")


def main():
    base.require(os.environ.get("SLURM_JOB_ID"), "checks require a compute allocation")
    check_parser()
    check_measurement()
    print(
        "NFS counter parsing, missing-counter failures, active intervals, and read floors verified"
    )


if __name__ == "__main__":
    main()
