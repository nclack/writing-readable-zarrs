"""Count bounded merged reads independently from native executor counters."""

import math
import struct
from collections import defaultdict

import cpu_pareto as base
import shard_grid_data as grid


def merged_ranges(ranges, max_bytes, max_chunks):
    groups = []
    for start, size in sorted(ranges):
        end = start + size
        if groups:
            first, last, count = groups[-1]
            if (
                start <= last
                and count < max_chunks
                and max(last, end) - first <= max_bytes
            ):
                groups[-1] = (first, max(last, end), count + 1)
                continue
        groups.append((start, end, 1))
    return groups


def read_geometry(data, audit, workload, workers):
    chunk = base.CHUNKS[audit["case"]["chunk_kib"]]
    inner = tuple(a // b for a, b in zip(audit["shard_shape"], chunk, strict=True))
    indexes = {}
    for row in audit["shards"]:
        with (data / row["path"]).open("rb") as stream:
            stream.seek(-row["index_bytes"], 2)
            indexes[tuple(row["coordinate"])] = list(
                struct.iter_unpack("<QQ", stream.read(row["index_bytes"] - 4))
            )
    count = size = 0
    batch_size = workload["samples_per_batch"]
    limit = min((math.prod(chunk) * 2 + 16) * workers, 2**32 - 1)
    for first in range(0, len(workload["queries"]), batch_size):
        chunks = set()
        for start in workload["queries"][first : first + batch_size]:
            chunks.update(grid.chunks_for_query(start, workload["sample_shape"], chunk))
        shards = defaultdict(list)
        for coordinate in chunks:
            shard, index = grid.chunk_location(coordinate, inner)
            shards[shard].append(indexes[shard][index])
        for ranges in shards.values():
            groups = merged_ranges(ranges, limit, workers)
            count += len(groups)
            size += sum(end - start for start, end, _ in groups)
    return {"merged_reads_per_pass": count, "merged_reader_bytes_per_pass": size}


def check_model():
    assert merged_ranges([(8, 8), (0, 8), (40, 8)], 32, 4) == [(0, 16, 2), (40, 48, 1)]
    assert merged_ranges([(0, 8), (4, 8)], 32, 4) == [(0, 12, 2)]
    assert merged_ranges([(0, 8), (8, 8), (16, 8)], 24, 2) == [(0, 16, 2), (16, 24, 1)]
    assert merged_ranges([(0, 8), (8, 8)], 8, 4) == [(0, 8, 1), (8, 16, 1)]
    print("Bounded merged-read model: passed")


if __name__ == "__main__":
    check_model()
