"""Count storage reads while controlling residency of benchmark files."""

import ctypes
import os
import time
from pathlib import Path

import cpu_pareto as base

PAGE = os.sysconf("SC_PAGE_SIZE")
MASK = bytes(value & 1 for value in range(256))
LIBC = ctypes.CDLL(None, use_errno=True)
LIBC.mmap.argtypes = [
    ctypes.c_void_p,
    ctypes.c_size_t,
    ctypes.c_int,
    ctypes.c_int,
    ctypes.c_int,
    ctypes.c_int64,
]
LIBC.mmap.restype = ctypes.c_void_p
LIBC.mincore.argtypes = [
    ctypes.c_void_p,
    ctypes.c_size_t,
    ctypes.POINTER(ctypes.c_ubyte),
]
LIBC.mincore.restype = ctypes.c_int
LIBC.munmap.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
LIBC.munmap.restype = ctypes.c_int


def process_io():
    return {
        key: int(value)
        for key, value in (
            line.split(":") for line in Path("/proc/self/io").read_text().splitlines()
        )
    }


def resident_pages(fd):
    size = os.fstat(fd).st_size
    pages = (size + PAGE - 1) // PAGE
    address = LIBC.mmap(None, size, 0, 1, fd, 0)
    if address == ctypes.c_void_p(-1).value:
        raise OSError(ctypes.get_errno(), "file residency mmap failed")
    try:
        vector = (ctypes.c_ubyte * pages)()
        if LIBC.mincore(address, size, vector):
            raise OSError(ctypes.get_errno(), "file residency mincore failed")
        return bytes(vector).translate(MASK).count(b"\1")
    finally:
        if LIBC.munmap(address, size):
            raise OSError(ctypes.get_errno(), "file residency munmap failed")


def difference(before, after):
    return {key: after[key] - value for key, value in before.items()}


class Files:
    def __init__(self, paths):
        self.paths = [Path(path) for path in paths]
        self.fds = []
        devices = {path.stat().st_dev for path in self.paths}
        base.require(len(devices) == 1, "shards must use one local filesystem")
        device = devices.pop()
        self.device = Path(f"/sys/dev/block/{os.major(device)}:{os.minor(device)}")
        base.require(
            (self.device / "stat").exists(), "local block-device counters unavailable"
        )
        self.devices = [self.device, *sorted((self.device / "slaves").iterdir())]

    def __enter__(self):
        try:
            for path in self.paths:
                fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC)
                self.fds.append(fd)
                os.fdatasync(fd)
        except BaseException:
            self.__exit__(None, None, None)
            raise
        return self

    def __exit__(self, *_):
        for fd in self.fds:
            os.close(fd)
        self.fds = []

    def residency(self):
        return [resident_pages(fd) for fd in self.fds]

    def evict(self):
        for attempt in range(100):
            self.last_eviction_attempts = attempt + 1
            for fd in self.fds:
                os.posix_fadvise(fd, 0, 0, os.POSIX_FADV_DONTNEED)
            counts = self.residency()
            before = process_io()["read_bytes"]
            time.sleep(0.02)
            settled = self.residency()
            after = process_io()["read_bytes"]
            if not any(counts) and not any(settled) and before == after:
                return settled
        base.require(False, f"shard pages remain cached: {settled}")

    def device_io(self):
        result = {}
        for device in self.devices:
            values = list(map(int, (device / "stat").read_text().split()))
            result[device.resolve().name] = {
                "read_bytes": values[2] * 512,
                "read_operations": values[0],
                "read_milliseconds": values[3],
                "io_milliseconds": values[9],
            }
        return result

    def description(self):
        return {
            "page_bytes": PAGE,
            "filesystem_device": self.device.resolve().name,
            "device_counters": [device.resolve().name for device in self.devices],
            "files": [
                {
                    "path": str(path),
                    "file_bytes": path.stat().st_size,
                    "allocated_bytes": path.stat().st_blocks * 512,
                }
                for path in self.paths
            ],
        }

    def measure(
        self,
        scan,
        *,
        cold,
        seconds,
        min_useful_bytes,
        useful_bytes_per_pass,
        minimum_storage_bytes,
        prepare=None,
    ):
        passes = []
        control_seconds = active_seconds = 0.0
        before_io = process_io()
        before_devices = self.device_io()
        started = time.perf_counter()
        while True:
            control_started = time.perf_counter()
            if prepare:
                prepare()
            before_residency = self.evict() if cold else self.residency()
            control_seconds += time.perf_counter() - control_started
            pass_io = process_io()
            pass_started = time.perf_counter()
            scan()
            elapsed = time.perf_counter() - pass_started
            delta = difference(pass_io, process_io())
            if cold:
                base.require(
                    delta["read_bytes"] >= minimum_storage_bytes,
                    f"insufficient actual storage reads: {delta['read_bytes']} < {minimum_storage_bytes}; resident_pages_before={before_residency}; eviction_attempts={self.last_eviction_attempts}; process_io={delta}",
                )
            active_seconds += elapsed
            passes.append(
                {
                    "active_seconds": elapsed,
                    "resident_pages_before": before_residency,
                    "eviction_attempts": self.last_eviction_attempts if cold else 0,
                    "eviction_stable_seconds": 0.02 if cold else 0.0,
                    "process_io": delta,
                }
            )
            if (
                active_seconds >= seconds
                and len(passes) * useful_bytes_per_pass >= min_useful_bytes
            ):
                break
        wall_seconds = time.perf_counter() - started
        after_io = process_io()
        after_devices = self.device_io()
        delta = difference(before_io, after_io)
        base.require(
            delta["read_bytes"] >= sum(p["process_io"]["read_bytes"] for p in passes),
            "inconsistent process read counters",
        )
        return {
            "passes": len(passes),
            "seconds": wall_seconds,
            "active_read_seconds": active_seconds,
            "cache_control_seconds": control_seconds,
            "cache_control_fraction": control_seconds / wall_seconds,
            "other_control_seconds": wall_seconds - active_seconds - control_seconds,
            "cache_mode": "cold before every pass" if cold else "warm",
            "storage_bytes": delta["read_bytes"],
            "storage_gib_s": delta["read_bytes"] / wall_seconds / base.GIB,
            "storage_active_gib_s": delta["read_bytes"] / active_seconds / base.GIB,
            "process_io": delta,
            "device_io": {
                key: difference(before_devices[key], value)
                for key, value in after_devices.items()
            },
            "minimum_storage_bytes_per_pass": minimum_storage_bytes,
            "pass_details": passes,
            "resident_pages_after": self.residency(),
        }
