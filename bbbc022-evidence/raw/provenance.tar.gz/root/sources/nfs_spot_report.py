"""Report paired cold-client NFS and local NVMe measurements."""

import argparse
import csv
import statistics
from collections import defaultdict
from pathlib import Path

import cpu_pareto as base
from cold_read_config import COLORS, LABELS

WORKLOAD_LABELS = {
    "random-1x256x256": "Translated 256 x 256 crops",
    "full-scan": "Full-volume scan",
}


def write_csv(path, rows):
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def median(rows, field):
    values = [row[field] for row in rows if row[field] is not None]
    return statistics.median(values) if values else None


def collect(results):
    complete = base.read_json(results / "complete.json")
    manifest = base.read_json(results / "manifest.json")
    rows, passes, devices = [], [], []
    for source in complete["results"]:
        data = base.read_json(results / source)
        case = data["case"]
        base.require(len(data["measurements"]) == 1, "expected one repetition per file")
        row = data["measurements"][0]
        key = {
            "codec": case["codec"],
            "chunk_kib": case["chunk_kib"],
            "block_kib": case["block_kib"],
            "workload": data["workload"],
            "implementation": data["implementation"],
            "storage_tier": row["storage_tier"],
            "repeat": row["repeat"],
        }
        base.require(
            data["workers"] == 32 and data["io_workers"] == 16,
            "reader worker counts differ",
        )
        base.require(
            row["output_bytes"] == 2 * row["useful_bytes"], "output byte count differs"
        )
        if row["storage_tier"] == "nfs":
            base.require(
                row["active_storage_bytes"] is None and row["storage_bytes"] is None,
                "NFS traffic incorrectly labeled as physical storage reads",
            )
        rows.append(
            dict(
                key,
                passes=row["passes"],
                active_seconds=row["active_read_seconds"],
                wall_seconds=row["seconds"],
                counter_seconds=row["counter_window_seconds"],
                compression_ratio=data["compression_ratio"],
                stored_bytes=data["stored_bytes"],
                output_float32_gib_s=row["output_float32_active_gib_s"],
                useful_uint16_gib_s=row["useful_uint16_active_gib_s"],
                local_storage_gib_s=row["storage_active_gib_s"],
                reader_gib_s=row["reader_active_gib_s"],
                reader_bytes=row["reader_bytes"],
                cpu_cores=sum(row["cpu"].values()) / row["active_read_seconds"],
                nfs_payload_gib_s=row["nfs_payload_gib_s"],
                nfs_read_operations_s=row["nfs_read_operations_s"],
                nfs_payload_bytes_per_read=row["nfs_payload_bytes_per_read"],
                nfs_read_rtt_ms=row["nfs_read_rtt_ms"],
                nfs_read_execute_ms=row["nfs_read_execute_ms"],
                nfs_read_queue_ms=row["nfs_read_queue_ms"],
                nfs_read_retransmissions=row["nfs_read_retransmissions"],
                nfs_read_errors=row["nfs_read_errors"],
                nfs_idle_max_gib_s=row["nfs_idle_max_gib_s"],
                nfs_idle_fraction_of_active=row["nfs_idle_fraction_of_active"],
                peak_rss_gib=data["peak_rss_bytes"] / base.GIB,
                source=source,
            )
        )
        for index, detail in enumerate(row["pass_details"], 1):
            base.require(
                not any(detail["resident_pages_before"]),
                "warm client pages before a pass",
            )
            base.require(
                detail["minimum_read_bytes_check"]
                >= row["minimum_storage_bytes_per_pass"],
                "read bytes below the required page union",
            )
            passes.append(
                dict(
                    key,
                    pass_index=index,
                    active_seconds=detail["active_seconds"],
                    counter_seconds=detail["counter_window_seconds"],
                    resident_pages_before=sum(detail["resident_pages_before"]),
                    eviction_attempts=detail["eviction_attempts"],
                    process_read_bytes=detail["process_io"]["read_bytes"],
                    nfs_payload_read_bytes=detail["nfs_io"]["payload_read_bytes"],
                    nfs_read_operations=detail["nfs_io"]["READ.operations"],
                    minimum_required_read_bytes=row["minimum_storage_bytes_per_pass"],
                )
            )
        for device, counters in row["device_io"].items():
            elapsed = row["counter_window_seconds"]
            ops = counters["read_operations"]
            devices.append(
                dict(
                    key,
                    device=device,
                    counter_seconds=elapsed,
                    read_gib_s=counters["read_bytes"] / elapsed / base.GIB,
                    read_operations_s=ops / elapsed,
                    bytes_per_read=counters["read_bytes"] / ops if ops else None,
                    read_latency_ms=counters["read_milliseconds"] / ops
                    if ops
                    else None,
                    busy_fraction=counters["io_milliseconds"] / (1000 * elapsed),
                    mean_io_in_progress=counters["weighted_io_milliseconds"]
                    / (1000 * elapsed),
                )
            )
    base.require(len(rows) == manifest["timed_repetitions"], "missing measurements")
    return manifest, rows, passes, devices


def aggregate(rows, repeats):
    keys = (
        "codec",
        "chunk_kib",
        "block_kib",
        "workload",
        "implementation",
        "storage_tier",
    )
    groups = defaultdict(list)
    for row in rows:
        groups[tuple(row[key] for key in keys)].append(row)
    result = []
    for key, group in sorted(groups.items()):
        base.require(
            len(group) == repeats and len({r["repeat"] for r in group}) == repeats,
            "missing or duplicated repetitions",
        )
        result.append(
            dict(
                zip(keys, key, strict=True),
                repetitions=len(group),
                compression_ratio=group[0]["compression_ratio"],
                output_float32_gib_s=median(group, "output_float32_gib_s"),
                output_min_gib_s=min(row["output_float32_gib_s"] for row in group),
                output_max_gib_s=max(row["output_float32_gib_s"] for row in group),
                useful_uint16_gib_s=median(group, "useful_uint16_gib_s"),
                local_storage_gib_s=median(group, "local_storage_gib_s"),
                nfs_payload_gib_s=median(group, "nfs_payload_gib_s"),
                nfs_read_operations_s=median(group, "nfs_read_operations_s"),
                nfs_payload_bytes_per_read=median(group, "nfs_payload_bytes_per_read"),
                nfs_read_rtt_ms=median(group, "nfs_read_rtt_ms"),
                nfs_read_execute_ms=median(group, "nfs_read_execute_ms"),
                nfs_read_queue_ms=median(group, "nfs_read_queue_ms"),
                nfs_idle_max_gib_s=max(row["nfs_idle_max_gib_s"] for row in group),
                cpu_cores=median(group, "cpu_cores"),
                peak_rss_gib=max(row["peak_rss_gib"] for row in group),
            )
        )
    return result


def compare(rows, historical):
    keys = ("codec", "chunk_kib", "block_kib", "workload", "implementation")
    grouped = defaultdict(dict)
    old = defaultdict(list)
    for row in rows:
        grouped[tuple(row[key] for key in keys)][row["repeat"], row["storage_tier"]] = (
            row
        )
    for row in csv.DictReader(historical.open()):
        key = (
            row["codec"],
            int(row["chunk_kib"]),
            int(row["block_kib"]),
            row["workload"],
            row["implementation"],
        )
        old[key].append(float(row["output_float32_active_gib_s"]))
    result = []
    for key, group in sorted(grouped.items()):
        repeats = sorted({repeat for repeat, _ in group})
        pairs = [(group[repeat, "local"], group[repeat, "nfs"]) for repeat in repeats]
        ratios = [
            nfs["output_float32_gib_s"] / local["output_float32_gib_s"]
            for local, nfs in pairs
        ]
        local_rate = statistics.median(
            local["output_float32_gib_s"] for local, _ in pairs
        )
        nfs_rate = statistics.median(nfs["output_float32_gib_s"] for _, nfs in pairs)
        result.append(
            dict(
                zip(keys, key, strict=True),
                local_output_gib_s=local_rate,
                nfs_output_gib_s=nfs_rate,
                paired_nfs_over_local=statistics.median(ratios),
                paired_ratio_min=min(ratios),
                paired_ratio_max=max(ratios),
                paired_change_percent=100 * (statistics.median(ratios) - 1),
                earlier_local_output_gib_s=statistics.median(old[key]),
                fresh_over_earlier_local=local_rate / statistics.median(old[key]),
            )
        )
    return result


def plots(output, manifest, summaries, comparisons):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np

    cases = [tuple(row) for row in manifest["encodings"]]
    labels = [f"{codec.upper()}\n{chunk}/{block} KiB" for codec, chunk, block in cases]
    figure, axes = plt.subplots(1, 2, figsize=(13, 5.8), constrained_layout=True)
    for axis, workload in zip(axes, manifest["workloads"], strict=True):
        for i, variant in enumerate(manifest["implementations"]):
            for tier, marker, shift in (("local", "o", -0.035), ("nfs", "s", 0.035)):
                group = [
                    next(
                        row
                        for row in summaries
                        if (row["codec"], row["chunk_kib"], row["block_kib"]) == case
                        and row["workload"] == workload
                        and row["implementation"] == variant
                        and row["storage_tier"] == tier
                    )
                    for case in cases
                ]
                values = np.array([row["output_float32_gib_s"] for row in group])
                errors = np.array(
                    [
                        [
                            value - row["output_min_gib_s"]
                            for value, row in zip(values, group, strict=True)
                        ],
                        [
                            row["output_max_gib_s"] - value
                            for value, row in zip(values, group, strict=True)
                        ],
                    ]
                )
                axis.errorbar(
                    np.arange(len(cases)) + (i - 1) * 0.17 + shift,
                    values,
                    yerr=errors,
                    marker=marker,
                    color=COLORS[variant],
                    linestyle="none",
                    capsize=3,
                    markerfacecolor=COLORS[variant] if tier == "local" else "white",
                    label=f"{LABELS[variant]} · {'NVMe' if tier == 'local' else 'NFS'}",
                )
        axis.set(
            xticks=range(len(cases)),
            xticklabels=labels,
            title=WORKLOAD_LABELS[workload],
            ylabel="Returned float32 GiB/s",
            xlabel="Codec; chunk / Blosc block size",
            ylim=(0, None),
        )
        axis.grid(axis="y", alpha=0.2)
    handles, legend_labels = axes[0].get_legend_handles_labels()
    figure.legend(
        handles, legend_labels, loc="outside lower center", ncol=2, fontsize=9
    )
    figure.suptitle(
        "Turin: matched local NVMe and NFS reads\nCold client cache · 32 decode workers · median and observed range"
    )
    for extension in ("png", "svg"):
        figure.savefig(output / f"output-comparison.{extension}", dpi=180)
    plt.close(figure)

    figure, axes = plt.subplots(1, 2, figsize=(13, 5), constrained_layout=True)
    for axis, workload in zip(axes, manifest["workloads"], strict=True):
        for i, variant in enumerate(manifest["implementations"]):
            group = [
                next(
                    row
                    for row in comparisons
                    if (row["codec"], row["chunk_kib"], row["block_kib"]) == case
                    and row["workload"] == workload
                    and row["implementation"] == variant
                )
                for case in cases
            ]
            values = np.array([row["paired_nfs_over_local"] for row in group])
            errors = np.array(
                [
                    [
                        value - row["paired_ratio_min"]
                        for value, row in zip(values, group, strict=True)
                    ],
                    [
                        row["paired_ratio_max"] - value
                        for value, row in zip(values, group, strict=True)
                    ],
                ]
            )
            axis.errorbar(
                np.arange(len(cases)) + (i - 1) * 0.18,
                values,
                yerr=errors,
                fmt="o",
                capsize=3,
                color=COLORS[variant],
                label=LABELS[variant],
            )
        axis.axhline(1, color="gray", linewidth=1)
        axis.set(
            xticks=range(len(cases)),
            xticklabels=labels,
            title=WORKLOAD_LABELS[workload],
            xlabel="Codec; chunk / Blosc block size",
            ylabel="NFS / local output throughput",
            ylim=(0, None),
        )
        axis.grid(axis="y", alpha=0.2)
    figure.legend(
        *axes[0].get_legend_handles_labels(),
        loc="outside lower center",
        ncol=3,
        fontsize=9,
    )
    figure.suptitle(
        "Effect of moving the same reads to NFS\n1 = unchanged · below 1 = slower on NFS · paired repetition ratios"
    )
    for extension in ("png", "svg"):
        figure.savefig(output / f"nfs-change.{extension}", dpi=180)
    plt.close(figure)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("results", "output", "historical"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    manifest, rows, passes, devices = collect(args.results)
    summaries = aggregate(rows, manifest["repeats"])
    comparisons = compare(rows, args.historical)
    for name, values in (
        ("repetitions", rows),
        ("passes", passes),
        ("devices", devices),
        ("summary", summaries),
        ("comparison", comparisons),
    ):
        if values:
            write_csv(args.output / f"{name}.csv", values)
    plots(args.output, manifest, summaries, comparisons)
    lines = [
        "# Turin: local NVMe versus NFS",
        "",
        "**Reduced preflight only: volume is smaller than the full protocol described below.**"
        if manifest["small"]
        else "Full-volume measurements.",
        "",
        "Matched CPU measurements of the same sixteen 1 GiB raw shards, with identical compressed files, queries, and reader sources. "
        "Both readers use 32 decode/copy participants and 16 file workers. Output is float32; useful uint16 bandwidth is half the returned byte rate.",
        "",
        "The client page cache is verified empty before every pass. Decoded caches are reset. NFS server caches are uncontrolled and may have been warmed by generation and validation. "
        "NFS payload bandwidth, request rates, and latency use shared client mount counters sampled around active reads; they are not process-attributed and do not measure server disk traffic. "
        "Idle traffic is recorded before and after each repetition, without subtracting it or claiming it bounds simultaneous interference.",
        "",
        "Median throughput and observed repetition ranges are shown; ranges are not confidence intervals. "
        "Compression is raw uint16 bytes divided by complete compressed shard-file bytes, including indexes. "
        "The four selected settings are spot checks, not a complete NFS Pareto frontier.",
        "",
        "![Output comparison](output-comparison.png)",
        "",
        "![NFS change](nfs-change.png)",
        "",
        "| Workload | Codec | Chunk/block KiB | Reader | Local output GiB/s | NFS output GiB/s | Paired NFS/local | Change |",
        "|---|---|---|---|---:|---:|---:|---:|",
    ]
    for row in comparisons:
        lines.append(
            f"| {WORKLOAD_LABELS[row['workload']]} | {row['codec']} | {row['chunk_kib']}/{row['block_kib']} | {LABELS[row['implementation']]} | "
            f"{row['local_output_gib_s']:.2f} | {row['nfs_output_gib_s']:.2f} | {row['paired_nfs_over_local']:.3f} | {row['paired_change_percent']:+.1f}% |"
        )
    lines += [
        "",
        f"Validated {len(rows)} repetitions and {len(passes)} cold passes. "
        "Fresh local results versus the earlier Turin sweep are in comparison.csv. "
        "Device counters include separate RAID, encrypted, and physical-drive layers; do not add those layers together.",
        "",
    ]
    (args.output / "README.md").write_text("\n".join(lines))
    base.write_json(
        args.output / "validation.json",
        {
            "repetitions": len(rows),
            "cold_passes": len(passes),
            "all_client_pages_cold": True,
            "nfs_physical_storage_fields_absent": True,
        },
    )
    print(f"Report: {args.output}; {len(rows)} repetitions, {len(passes)} cold passes")


if __name__ == "__main__":
    main()
