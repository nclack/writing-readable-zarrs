"""Pair local and NFS reads of byte-identical sharded arrays."""

import argparse
import os
import random
import shutil
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import cpu_pareto as base
from cold_read_config import SETTINGS


def schedules(plan, repeats):
    generation = list(plan["encodings"])
    random.Random(base.SEED + 1).shuffle(generation)
    result = []
    for repeat in range(1, repeats + 1):
        encodings = list(plan["encodings"])
        random.Random(base.SEED + 100 * repeat).shuffle(encodings)
        for encoding in encodings:
            case_index = plan["encodings"].index(encoding)
            workloads = list(plan["workloads"])
            random.Random(base.SEED + 1000 * repeat + case_index).shuffle(workloads)
            for workload in workloads:
                order = 2 * case_index + plan["workloads"].index(workload)
                variants = list(plan["implementations"])
                if order % 2:
                    variants.reverse()
                start = (order + repeat - 1) % len(variants)
                variants = variants[start:] + variants[:start]
                for variant in variants:
                    variant_index = plan["implementations"].index(variant)
                    tiers = list(plan["storage_tiers"])
                    if (order + variant_index + repeat) % 2:
                        tiers.reverse()
                    for tier in tiers:
                        result.append(
                            dict(
                                codec=encoding[0],
                                chunk_kib=encoding[1],
                                block_kib=encoding[2],
                                workload=workload,
                                implementation=variant,
                                storage_tier=tier,
                                repeat=repeat,
                            )
                        )
    return generation, result


def child(command, log, env):
    with log.open("x") as stream:
        result = subprocess.run(
            command, stdout=stream, stderr=subprocess.STDOUT, env=env
        )
    print(log.read_text()[-6000:], end="", flush=True)
    if result.returncode:
        raise subprocess.CalledProcessError(result.returncode, command)


def copy_dataset(source, destination, audit):
    destination.mkdir(parents=True, exist_ok=True)

    def copy_file(path):
        target = destination / path.relative_to(source)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
        with target.open("rb") as stream:
            os.fdatasync(stream.fileno())

    with ThreadPoolExecutor(max_workers=4) as pool:
        list(
            pool.map(copy_file, (path for path in source.rglob("*") if path.is_file()))
        )

    def check(row):
        path = destination / row["path"]
        base.require(
            path.stat().st_size == row["file_bytes"], "NFS copy has wrong size"
        )
        base.require(base.digest(path) == row["sha256"], "NFS shard hash differs")
        return {"path": row["path"], "sha256": row["sha256"]}

    with ThreadPoolExecutor(max_workers=4) as pool:
        shards = list(pool.map(check, audit["shards"]))
    return {"shards": shards, "byte_identical": True}


def measure(args, run, seconds, min_gib):
    name = base.case_id(dict(input="smooth4", **run))
    tier, variant = run["storage_tier"], run["implementation"]
    folder = args.output / name
    destination = folder / tier / run["workload"] / f"repeat-{run['repeat']}" / variant
    destination.mkdir(parents=True)
    dataset = (args.local_data if tier == "local" else args.nfs_data) / name
    sources = Path(__file__).resolve().parent
    env = os.environ.copy()
    env.pop("DAMACY_BENCH_READ_MODE", None)
    env.pop("DAMACY_BENCH_CPU_READ_CHUNKS", None)
    env["DAMACY_STORAGE_TIER"] = tier
    if variant != "tensorstore":
        env["DAMACY_BENCH_READ_MODE"] = SETTINGS[variant]["file_read_mode"]
    env["PYTHONPATH"] = str(sources) + (
        os.pathsep + str(args.native_python) if variant != "tensorstore" else ""
    )
    command = [
        sys.executable,
        str(sources / "shard_grid_measure.py"),
        "--data",
        str(dataset),
        "--audit",
        str(folder / "audit.json"),
        "--references",
        str(folder / "references.json"),
        "--workers",
        "32",
        "--io-workers",
        "16",
        "--cores",
        "48",
        "--backend",
        "tensorstore" if variant == "tensorstore" else "damacy",
        "--implementation",
        variant,
        "--output",
        str(destination / "measurements.json"),
        "--workload",
        run["workload"],
        "--cache",
        "cold",
        "--repeat-index",
        str(run["repeat"]),
        "--repeats",
        "1",
        "--seconds",
        str(seconds),
        "--min-gib",
        str(min_gib),
    ]
    if variant != "tensorstore":
        command += ["--identity", str(args.identities / "damacy.json")]
    attempts = []
    for attempt in range(1, 4):
        log = destination / f"attempt-{attempt}.log"
        try:
            child(command, log, env)
        except subprocess.CalledProcessError as error:
            cached = "RuntimeError: shard pages remain cached:" in log.read_text()
            attempts.append(
                {
                    "attempt": attempt,
                    "status": "cached pages" if cached else "failed",
                    "returncode": error.returncode,
                }
            )
            base.write_json(destination / "attempts.json", attempts)
            if not cached or attempt == 3:
                raise
        else:
            attempts.append({"attempt": attempt, "status": "complete"})
            base.write_json(destination / "attempts.json", attempts)
            return str((destination / "measurements.json").relative_to(args.output))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in (
        "root",
        "local-data",
        "nfs-data",
        "cache",
        "output",
        "identities",
        "native-python",
    ):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--small", action="store_true")
    args = parser.parse_args()
    base.require(os.environ.get("SLURM_JOB_ID"), "compute allocation required")
    base.require(not os.environ.get("LD_PRELOAD"), "unexpected instrumentation")
    plan = base.read_json(args.root / "plan.json")
    for path in (args.local_data, args.cache, args.output):
        path.mkdir(parents=True, exist_ok=False)
    args.nfs_data.mkdir(parents=True, exist_ok=True)
    generation, schedule = schedules(plan, 1 if args.small else plan["repeats"])
    seconds, min_gib = (
        (0.1, 0.01)
        if args.small
        else (plan["minimum_active_seconds"], plan["minimum_useful_gib"])
    )
    manifest = dict(
        plan,
        small=args.small,
        timed_repetitions=len(schedule),
        repeats=1 if args.small else plan["repeats"],
        seconds=seconds,
        min_gib=min_gib,
    )
    base.write_json(args.output / "manifest.json", manifest)
    base.write_json(args.output / "generation-order.json", generation)
    base.write_json(args.output / "run-order.json", schedule)
    results, generated = [], []
    source_hashes = reference_hash = None
    started = time.perf_counter()

    def progress(stage):
        base.write_json(
            args.output / "progress.json",
            {
                "stage": stage,
                "generated": generated,
                "results": results,
                "elapsed_seconds": time.perf_counter() - started,
            },
        )

    for codec, chunk, block in generation:
        name = f"smooth4-{codec}-c{chunk}-b{block}"
        folder = args.output / name
        folder.mkdir()
        shutil.copyfile(
            args.root / "historical" / name / "case.json", folder / "case.json"
        )
        env = os.environ.copy()
        env["PYTHONPATH"] = str(Path(__file__).resolve().parent)
        command = [
            sys.executable,
            str(Path(__file__).with_name("shard_grid_data.py")),
            "--case",
            str(folder / "case.json"),
            "--data",
            str(args.local_data / name),
            "--cache",
            str(args.cache),
            "--output",
            str(folder),
        ]
        if args.small:
            command.append("--small")
        print(
            f"Generating {len(generated) + 1}/{len(generation)}: {name}; small={args.small}",
            flush=True,
        )
        child(command, folder / "generate.log", env)
        audit = base.read_json(folder / "audit.json")
        hashes = [row["source_sha256"] for row in audit["shards"]]
        current_reference = base.digest(folder / "references.json")
        if source_hashes is None:
            source_hashes, reference_hash = hashes, current_reference
        base.require(
            hashes == source_hashes and current_reference == reference_hash,
            "source or queries changed between encodings",
        )
        if not args.small:
            historical = args.root / "historical" / name
            old = base.read_json(historical / "audit.json")
            for actual, wanted in zip(audit["shards"], old["shards"], strict=True):
                for key in ("source_sha256", "sha256", "file_bytes", "path"):
                    base.require(
                        actual[key] == wanted[key],
                        f"historical encoding differs: {name} {key}",
                    )
            base.require(
                current_reference == base.digest(historical / "references.json"),
                "queries differ from the earlier sweep",
            )
        copied = copy_dataset(args.local_data / name, args.nfs_data / name, audit)
        copied["historical_files_match"] = None if args.small else True
        base.write_json(folder / "identity.json", copied)
        generated.append(name)
        progress("generation")
    for index, run in enumerate(schedule, 1):
        print(f"Timing {index}/{len(schedule)}: {run}", flush=True)
        results.append(measure(args, run, seconds, min_gib))
        progress("timing")
    base.require(len(results) == manifest["timed_repetitions"], "incomplete schedule")
    base.write_json(
        args.output / "complete.json",
        {
            "results": results,
            "repetitions": len(results),
            "source_hashes": source_hashes,
            "references_sha256": reference_hash,
            "elapsed_seconds": time.perf_counter() - started,
            "nfs_data": str(args.nfs_data),
        },
    )
    progress("complete")


if __name__ == "__main__":
    main()
